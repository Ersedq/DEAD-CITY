#ifndef ARMA_H
#define ARMA_H

#include <glm/glm.hpp>

struct GLFWwindow;

// Municion llena y pistola en mano
void ArmaReiniciar();

// Controles: clic izquierdo = disparar, R = recargar, 1 / 2 / 3 = cambiar de arma.
// "activo" = false desactiva los controles (por ejemplo, en la pantalla de game over).
void ArmaActualizar(GLFWwindow* ventana, float deltaTime, bool activo);

// Dibuja el arma en primera persona
void ArmaDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
);

// Recompensa al terminar una oleada: mas municion de reserva
void ArmaRecompensaOleada();

// Suma municion de reserva a todas las armas (1.0 = la reserva inicial completa).
// La usan los coleccionables de municion.
void ArmaAgregarMunicion(float factor);

// ---- DATOS PARA EL HUD ----
int ArmaActual();
const char* ArmaNombre(int indice);
int ArmaCargador();
int ArmaCargadorMax();
int ArmaReserva();
bool ArmaRecargando();
float ArmaProgresoRecarga();      // 0 a 1

// Marca de impacto en la mira: 0 a 1 (baja con el tiempo)
float ArmaMarcadorImpacto();
bool ArmaMarcadorMuerte();

#endif
