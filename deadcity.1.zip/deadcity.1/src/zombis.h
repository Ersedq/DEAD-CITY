#ifndef ZOMBIS_H
#define ZOMBIS_H

#include <glm/glm.hpp>

// Empieza la partida desde la oleada 1 (borra todos los zombis)
void ZombisReiniciar();

// Mueve los zombis, los hace atacar y controla las oleadas
void ZombisActualizar(float deltaTime, glm::vec3 posicionJugador);

void ZombisDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
);

// Dispara un rayo (bala). Devuelve: 0 = fallo, 1 = impacto, 2 = zombi eliminado
int ZombisDisparar(
    glm::vec3 origen,
    glm::vec3 direccion,
    float dano,
    float alcance
);

int ZombisOleadaActual();
int ZombisOleadasTotales();

// Zombis vivos + los que todavia faltan por aparecer en la oleada
int ZombisRestantes();

int ZombisEliminados();

// Segundos que faltan para que empiece la siguiente oleada (0 si hay combate)
float ZombisPausaOleada();

// Puntos acumulados por eliminar zombis (los fuertes y los tiros a la cabeza dan mas)
int ZombisPuntos();

// true cuando se vencen todas las oleadas (despues hay que llegar a la extraccion)
bool ZombisOleadasCompletadas();

// Durante la extraccion siguen llegando zombis
void ZombisActivarRefuerzos();

#endif
