
// IMPORTANTE: GLEW siempre antes que GLFW
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "arma.h"
#include "zombis.h"
#include "jugador.h"
#include "mundo.h"
#include "azar.h"

#include <glm/gtc/matrix_transform.hpp>

#include <cmath>
#include <algorithm>

static const int ARMAS_TOTAL = 3;

struct DatosArma
{
    const char* nombre;
    float dano;           // dano por bala (un zombi tiene 100 de vida)
    int perdigones;       // balas por disparo (la escopeta lanza varias)
    float cadencia;       // segundos entre disparos
    int cargador;         // balas por cargador
    int reservaInicial;
    int reservaMaxima;
    float recarga;        // segundos para recargar
    float dispersion;     // grados de desvio
    bool automatica;      // true = mantener el clic dispara sin parar
    float alcance;
};

// ---------------- AJUSTES DE LAS ARMAS ----------------
static const DatosArma ARMAS[ARMAS_TOTAL] =
{
    //  nombre      dano  perd  cadencia  carg  reserva  max  recarga  disp  auto   alcance
    { "PISTOLA",    34.0f, 1,   0.30f,    12,   48,      96,  1.2f,    0.5f, false, 60.0f },
    { "RIFLE",      20.0f, 1,   0.10f,    30,   90,      180, 2.0f,    1.8f, true,  80.0f },
    { "ESCOPETA",   16.0f, 8,   0.85f,    6,    18,      36,  2.2f,    5.5f, false, 25.0f }
};
// ------------------------------------------------------

static int armaActual = 0;
static int cargador[ARMAS_TOTAL];
static int reserva[ARMAS_TOTAL];

static float enfriamiento = 0.0f;
static bool recargando = false;
static float tiempoRecarga = 0.0f;

static float retroceso = 0.0f;
static float destello = 0.0f;
static float marcador = 0.0f;
static bool marcadorMuerte = false;

static bool botonAnterior = false;

static const float DURACION_MARCADOR = 0.18f;

// ---------------------------------------------------------------------------

void ArmaReiniciar()
{
    for (int i = 0; i < ARMAS_TOTAL; i++)
    {
        cargador[i] = ARMAS[i].cargador;
        reserva[i] = ARMAS[i].reservaInicial;
    }

    armaActual = 0;
    enfriamiento = 0.0f;
    recargando = false;
    tiempoRecarga = 0.0f;
    retroceso = 0.0f;
    destello = 0.0f;
    marcador = 0.0f;
}

static void IniciarRecarga()
{
    if (recargando)
        return;

    if (cargador[armaActual] >= ARMAS[armaActual].cargador)
        return;

    if (reserva[armaActual] <= 0)
        return;

    recargando = true;
    tiempoRecarga = 0.0f;
}

static void Disparar()
{
    const DatosArma& datos = ARMAS[armaActual];

    cargador[armaActual]--;
    enfriamiento = datos.cadencia;
    retroceso = 1.0f;
    destello = 0.06f;

    glm::vec3 origen = JugadorObtenerPosicion();
    glm::vec3 frente = JugadorObtenerFrente();

    glm::vec3 derecha = glm::normalize(
        glm::cross(frente, glm::vec3(0.0f, 1.0f, 0.0f))
    );

    glm::vec3 arriba = glm::cross(derecha, frente);

    float desvio = std::tan(glm::radians(datos.dispersion));

    int resultado = 0;

    for (int i = 0; i < datos.perdigones; i++)
    {
        glm::vec3 direccion = glm::normalize(
            frente
            + derecha * (Azar(-1.0f, 1.0f) * desvio)
            + arriba * (Azar(-1.0f, 1.0f) * desvio)
        );

        int r = ZombisDisparar(origen, direccion, datos.dano, datos.alcance);

        resultado = std::max(resultado, r);
    }

    if (resultado > 0)
    {
        marcador = DURACION_MARCADOR;
        marcadorMuerte = (resultado == 2);
    }

    // Si se vacia el cargador, recarga sola
    if (cargador[armaActual] == 0)
        IniciarRecarga();
}

void ArmaActualizar(GLFWwindow* ventana, float deltaTime, bool activo)
{
    enfriamiento = std::max(0.0f, enfriamiento - deltaTime);
    retroceso = std::max(0.0f, retroceso - deltaTime * 6.0f);
    destello = std::max(0.0f, destello - deltaTime);
    marcador = std::max(0.0f, marcador - deltaTime);

    bool botonPulsado =
        glfwGetMouseButton(ventana, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;

    bool clicNuevo = botonPulsado && !botonAnterior;
    botonAnterior = botonPulsado;

    if (!activo)
        return;

    const DatosArma& datos = ARMAS[armaActual];

    // CAMBIAR DE ARMA (teclas 1, 2 y 3)
    for (int i = 0; i < ARMAS_TOTAL; i++)
    {
        if (glfwGetKey(ventana, GLFW_KEY_1 + i) == GLFW_PRESS
            && i != armaActual)
        {
            armaActual = i;
            recargando = false;
            enfriamiento = 0.25f;
            return;
        }
    }

    // RECARGAR
    if (glfwGetKey(ventana, GLFW_KEY_R) == GLFW_PRESS)
        IniciarRecarga();

    if (recargando)
    {
        tiempoRecarga += deltaTime;

        if (tiempoRecarga >= datos.recarga)
        {
            int falta = datos.cargador - cargador[armaActual];
            int mover = std::min(falta, reserva[armaActual]);

            cargador[armaActual] += mover;
            reserva[armaActual] -= mover;

            recargando = false;
        }

        return;   // no se puede disparar mientras recargas
    }

    // DISPARAR
    bool quiereDisparar = datos.automatica ? botonPulsado : clicNuevo;

    if (quiereDisparar && enfriamiento <= 0.0f)
    {
        if (cargador[armaActual] > 0)
            Disparar();
        else
            IniciarRecarga();
    }
}

// Suma municion de reserva a TODAS las armas.
// factor 1.0 = la reserva inicial completa de cada arma.
void ArmaAgregarMunicion(float factor)
{
    for (int i = 0; i < ARMAS_TOTAL; i++)
    {
        int extra = (int)std::ceil((float)ARMAS[i].reservaInicial * factor);

        reserva[i] = std::min(ARMAS[i].reservaMaxima, reserva[i] + extra);
    }
}

void ArmaRecompensaOleada()
{
    ArmaAgregarMunicion(0.5f);
}

// ---------------------------------------------------------------------------
//  DIBUJO DEL ARMA EN PRIMERA PERSONA
// ---------------------------------------------------------------------------

struct ParteArma
{
    glm::vec3 posicion;
    glm::vec3 tamano;
    glm::vec3 color;
};

static const ParteArma PISTOLA[] =
{
    { glm::vec3(0.0f,  0.015f, -0.10f), glm::vec3(0.055f, 0.070f, 0.28f), glm::vec3(0.35f, 0.35f, 0.40f) },
    { glm::vec3(0.0f, -0.075f,  0.01f), glm::vec3(0.050f, 0.150f, 0.07f), glm::vec3(0.30f, 0.18f, 0.10f) },
    { glm::vec3(0.0f, -0.025f, -0.04f), glm::vec3(0.050f, 0.030f, 0.12f), glm::vec3(0.25f, 0.25f, 0.28f) }
};

static const ParteArma RIFLE[] =
{
    { glm::vec3(0.0f,  0.000f, -0.15f), glm::vec3(0.070f, 0.090f, 0.50f), glm::vec3(0.30f, 0.32f, 0.30f) },
    { glm::vec3(0.0f,  0.012f, -0.58f), glm::vec3(0.035f, 0.035f, 0.38f), glm::vec3(0.20f, 0.20f, 0.22f) },
    { glm::vec3(0.0f, -0.020f,  0.20f), glm::vec3(0.060f, 0.110f, 0.22f), glm::vec3(0.30f, 0.20f, 0.12f) },
    { glm::vec3(0.0f, -0.100f, -0.08f), glm::vec3(0.050f, 0.140f, 0.07f), glm::vec3(0.18f, 0.18f, 0.20f) },
    { glm::vec3(0.0f,  0.065f, -0.30f), glm::vec3(0.020f, 0.040f, 0.02f), glm::vec3(0.15f, 0.15f, 0.15f) }
};

static const ParteArma ESCOPETA[] =
{
    { glm::vec3(0.0f,  0.000f, -0.12f), glm::vec3(0.080f, 0.080f, 0.45f), glm::vec3(0.35f, 0.22f, 0.12f) },
    { glm::vec3(0.0f,  0.045f, -0.45f), glm::vec3(0.045f, 0.045f, 0.60f), glm::vec3(0.25f, 0.25f, 0.28f) },
    { glm::vec3(0.0f, -0.030f, -0.38f), glm::vec3(0.090f, 0.060f, 0.16f), glm::vec3(0.40f, 0.26f, 0.14f) },
    { glm::vec3(0.0f, -0.020f,  0.18f), glm::vec3(0.060f, 0.110f, 0.20f), glm::vec3(0.35f, 0.22f, 0.12f) }
};

// El escenario es muy oscuro, asi que el arma se aclara para que se vea
static const float BRILLO_ARMA = 4.0f;

void ArmaDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    // El arma siempre se ve encima de las paredes
    glClear(GL_DEPTH_BUFFER_BIT);

    const ParteArma* partes = PISTOLA;
    int cantidad = 3;
    float puntaZ = -0.26f;

    if (armaActual == 1)
    {
        partes = RIFLE;
        cantidad = 5;
        puntaZ = -0.80f;
    }
    else if (armaActual == 2)
    {
        partes = ESCOPETA;
        cantidad = 4;
        puntaZ = -0.78f;
    }

    // Animacion de recarga: el arma baja y se inclina
    float progreso = ArmaProgresoRecarga();
    float bajada = recargando ? std::sin(progreso * 3.14159f) : 0.0f;

    glm::mat4 camara = glm::inverse(vista);

    glm::mat4 base = glm::translate(
        camara,
        glm::vec3(0.24f, -0.22f - bajada * 0.18f, -0.45f + retroceso * 0.08f)
    );

    base = glm::rotate(
        base,
        glm::radians(retroceso * 5.0f - bajada * 35.0f),
        glm::vec3(1.0f, 0.0f, 0.0f)
    );

    for (int i = 0; i < cantidad; i++)
    {
        glm::mat4 modelo = glm::translate(base, partes[i].posicion);
        modelo = glm::scale(modelo, partes[i].tamano);

        MundoDibujarCuboModelo(
            vista, proyeccion, modelo,
            partes[i].color * BRILLO_ARMA
        );
    }

    // Fogonazo al disparar
    if (destello > 0.0f)
    {
        glm::mat4 modelo = glm::translate(
            base, glm::vec3(0.0f, 0.02f, puntaZ - 0.05f)
        );

        modelo = glm::scale(modelo, glm::vec3(0.11f, 0.11f, 0.11f));

        MundoDibujarCuboModelo(
            vista, proyeccion, modelo,
            glm::vec3(6.0f, 5.0f, 1.5f)
        );
    }
}

// ---------------------------------------------------------------------------
//  DATOS PARA EL HUD
// ---------------------------------------------------------------------------

int ArmaActual()
{
    return armaActual;
}

const char* ArmaNombre(int indice)
{
    return ARMAS[indice].nombre;
}

int ArmaCargador()
{
    return cargador[armaActual];
}

int ArmaCargadorMax()
{
    return ARMAS[armaActual].cargador;
}

int ArmaReserva()
{
    return reserva[armaActual];
}

bool ArmaRecargando()
{
    return recargando;
}

float ArmaProgresoRecarga()
{
    if (!recargando)
        return 0.0f;

    return std::min(1.0f, tiempoRecarga / ARMAS[armaActual].recarga);
}

float ArmaMarcadorImpacto()
{
    return marcador / DURACION_MARCADOR;
}

bool ArmaMarcadorMuerte()
{
    return marcadorMuerte;
}
