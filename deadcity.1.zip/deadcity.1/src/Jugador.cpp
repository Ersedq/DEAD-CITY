
#include "jugador.h"
#include "rayos.h"
#include "escenario.h"

#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <cmath>

// POSICION INICIAL DEL JUGADOR
glm::vec3 posicionJugador(JUGADOR_INICIO_X, 1.5f, JUGADOR_INICIO_Z);

// DIRECCION DE LA CAMARA
float yaw = -90.0f;
float pitch = 0.0f;

// VELOCIDAD
float velocidadNormal = 6.0f;
float velocidadCarrera = 11.0f;

// CONTROL DEL MOUSE
float ultimaX = 640.0f;
float ultimaY = 360.0f;
bool primerMovimiento = true;
bool mouseBloqueado = true;

// VIDA
const float vidaMaxima = 100.0f;
float vidaJugador = vidaMaxima;
float destelloDano = 0.0f;

// SALTO Y GRAVEDAD
float velocidadVertical = 0.0f;
bool enSuelo = true;

const float gravedad = -18.0f;
const float fuerzaSalto = 6.5f;

// COLISIONES: los edificios, farolas, barriles y escombros salen de escenario.h

const float radioJugador = 0.4f;

// COMPROBAR SI UNA POSICION ESTA LIBRE

// Comprueba colision entre el jugador y una caja
bool ColisionCaja(
    glm::vec2 jugador,
    glm::vec2 centro,
    glm::vec2 mitad
)
{
    glm::vec2 puntoCercano = glm::clamp(
        jugador,
        centro - mitad,
        centro + mitad
    );

    glm::vec2 diferencia = jugador - puntoCercano;

    return glm::dot(diferencia, diferencia)
        < radioJugador * radioJugador;
}


// Comprueba colisiones con farolas, barriles y escombros
bool ColisionaConObjetos(glm::vec3 posicion)
{
    glm::vec2 jugador(posicion.x, posicion.z);

    // FAROLAS
    for (int i = 0; i < FAROLAS_TOTAL; i++)
    {
        if (ColisionCaja(jugador, FAROLAS[i], glm::vec2(0.45f, 0.45f)))
            return true;
    }


    // BARRILES
    for (int i = 0; i < BARRILES_TOTAL; i++)
    {
        if (ColisionCaja(jugador, BARRILES[i], glm::vec2(0.40f, 0.40f)))
            return true;
    }


    // ESCOMBROS
    for (int g = 0; g < ESCOMBROS_TOTAL; g++)
    {
        const glm::vec2 grupo = ESCOMBROS[g];

        // Caja de carton
        if (ColisionCaja(
            jugador,
            grupo,
            glm::vec2(0.35f, 0.35f)
        ))
            return true;

        // Bolsa de basura
        if (ColisionCaja(
            jugador,
            grupo + glm::vec2(0.55f, 0.25f),
            glm::vec2(0.30f, 0.28f)
        ))
            return true;

        // Piedra grande
        if (ColisionCaja(
            jugador,
            grupo + glm::vec2(-0.45f, 0.45f),
            glm::vec2(0.20f, 0.16f)
        ))
            return true;

        // Piedra pequeña
        if (ColisionCaja(
            jugador,
            grupo + glm::vec2(0.25f, -0.45f),
            glm::vec2(0.12f, 0.12f)
        ))
            return true;
    }

    return false;
}


// Comprueba todas las colisiones del escenario
bool PuedeMoverse(glm::vec3 posicion)
{
    glm::vec2 jugador(posicion.x, posicion.z);

    // LIMITES DEL MAPA (la pared exterior)
    if (std::abs(jugador.x) > LIMITE_MOVIMIENTO
        || std::abs(jugador.y) > LIMITE_MOVIMIENTO)
        return false;

    // EDIFICIOS
    for (int i = 0; i < EDIFICIOS_TOTAL; i++)
    {
        if (ColisionCaja(jugador, EDIFICIOS[i].centro, EDIFICIOS[i].mitad))
            return false;
    }

    // OBJETOS DEL ESCENARIO
    if (ColisionaConObjetos(posicion))
        return false;

    return true;
}


// Distancia hasta el primer edificio que cruza el rayo
float DistanciaRayoEdificios(
    glm::vec3 origen,
    glm::vec3 direccion,
    float distanciaMax
)
{
    float mejor = distanciaMax;

    for (int i = 0; i < EDIFICIOS_TOTAL; i++)
    {
        const EdificioDatos& e = EDIFICIOS[i];

        glm::vec3 minimo(
            e.centro.x - e.mitad.x,
            BASE_EDIFICIOS,
            e.centro.y - e.mitad.y
        );

        glm::vec3 maximo(
            e.centro.x + e.mitad.x,
            BASE_EDIFICIOS + e.altura,
            e.centro.y + e.mitad.y
        );

        float d;

        if (RayoContraCaja(origen, direccion, minimo, maximo, d) && d < mejor)
            mejor = d;
    }

    return mejor;
}


// PROCESAR MOVIMIENTO DEL MOUSE
void ProcesarMouse(GLFWwindow* ventana, double xpos, double ypos)
{
    if (!mouseBloqueado)
        return;

    if (primerMovimiento)
    {
        ultimaX = (float)xpos;
        ultimaY = (float)ypos;
        primerMovimiento = false;
    }

    float desplazamientoX = (float)xpos - ultimaX;
    float desplazamientoY = ultimaY - (float)ypos;

    ultimaX = (float)xpos;
    ultimaY = (float)ypos;

    float sensibilidad = 0.10f;

    yaw += desplazamientoX * sensibilidad;
    pitch += desplazamientoY * sensibilidad;

    if (pitch > 89.0f)
        pitch = 89.0f;

    if (pitch < -89.0f)
        pitch = -89.0f;
}

// INICIALIZAR JUGADOR
void JugadorInicializar(GLFWwindow* ventana)
{
    glfwSetInputMode(
        ventana,
        GLFW_CURSOR,
        GLFW_CURSOR_DISABLED
    );

    glfwSetCursorPosCallback(ventana, ProcesarMouse);

    std::cout << "Jugador inicializado correctamente." << std::endl;
}

// PROCESAR TECLADO Y MOVIMIENTO
void JugadorProcesarEntrada(GLFWwindow* ventana, float deltaTime)
{
    // LIBERAR MOUSE CON ESCAPE
    if (glfwGetKey(ventana, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        mouseBloqueado = false;

        glfwSetInputMode(
            ventana,
            GLFW_CURSOR,
            GLFW_CURSOR_NORMAL
        );
    }

    // RECUPERAR MOUSE CON CLIC IZQUIERDO
    if (glfwGetMouseButton(ventana, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
    {
        if (!mouseBloqueado)
        {
            mouseBloqueado = true;
            primerMovimiento = true;

            glfwSetInputMode(
                ventana,
                GLFW_CURSOR,
                GLFW_CURSOR_DISABLED
            );
        }
    }

    // SI ESTAS MUERTO NO TE PUEDES MOVER (pero si caes de un salto, sigues cayendo)
    if (vidaJugador <= 0.0f)
    {
        velocidadVertical += gravedad * deltaTime;
        posicionJugador.y += velocidadVertical * deltaTime;

        if (posicionJugador.y <= 1.5f)
        {
            posicionJugador.y = 1.5f;
            velocidadVertical = 0.0f;
            enSuelo = true;
        }

        return;
    }

    // DIRECCION DE LA CAMARA
    glm::vec3 frente;

    frente.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    frente.y = sin(glm::radians(pitch));
    frente.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

    frente = glm::normalize(frente);

    glm::vec3 derecha = glm::normalize(
        glm::cross(frente, glm::vec3(0.0f, 1.0f, 0.0f))
    );

    // MOVIMIENTO HORIZONTAL
    glm::vec3 movimientoFrente = glm::normalize(
        glm::vec3(frente.x, 0.0f, frente.z)
    );

    float velocidad = velocidadNormal;

    if (glfwGetKey(ventana, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
        velocidad = velocidadCarrera;

    float desplazamiento = velocidad * deltaTime;

 // CALCULAR DIRECCION DEL MOVIMIENTO
glm::vec3 movimiento(0.0f);

if (glfwGetKey(ventana, GLFW_KEY_W) == GLFW_PRESS)
    movimiento += movimientoFrente;

if (glfwGetKey(ventana, GLFW_KEY_S) == GLFW_PRESS)
    movimiento -= movimientoFrente;

if (glfwGetKey(ventana, GLFW_KEY_A) == GLFW_PRESS)
    movimiento -= derecha;

if (glfwGetKey(ventana, GLFW_KEY_D) == GLFW_PRESS)
    movimiento += derecha;

// NORMALIZAR PARA EVITAR VELOCIDAD DIAGONAL
if (glm::length(movimiento) > 0.0f)
{
    movimiento = glm::normalize(movimiento) * desplazamiento;

    // PROBAR MOVIMIENTO EN X
    glm::vec3 nuevaPosicion = posicionJugador;
    nuevaPosicion.x += movimiento.x;

    if (PuedeMoverse(nuevaPosicion))
        posicionJugador.x = nuevaPosicion.x;

    // PROBAR MOVIMIENTO EN Z
    nuevaPosicion = posicionJugador;
    nuevaPosicion.z += movimiento.z;

    if (PuedeMoverse(nuevaPosicion))
        posicionJugador.z = nuevaPosicion.z;
}

    // SALTO
    if (glfwGetKey(ventana, GLFW_KEY_SPACE) == GLFW_PRESS && enSuelo)
    {
        velocidadVertical = fuerzaSalto;
        enSuelo = false;
    }

    // GRAVEDAD
    velocidadVertical += gravedad * deltaTime;
    posicionJugador.y += velocidadVertical * deltaTime;

    // ALTURA DEL SUELO
    if (posicionJugador.y <= 1.5f)
    {
        posicionJugador.y = 1.5f;
        velocidadVertical = 0.0f;
        enSuelo = true;
    }
}

// OBTENER CAMARA EN PRIMERA PERSONA
glm::mat4 JugadorObtenerVista()
{
    glm::vec3 frente;

    frente.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    frente.y = sin(glm::radians(pitch));
    frente.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

    frente = glm::normalize(frente);

    return glm::lookAt(
        posicionJugador,
        posicionJugador + frente,
        glm::vec3(0.0f, 1.0f, 0.0f)
    );
}

// OBTENER POSICION DEL JUGADOR
glm::vec3 JugadorObtenerPosicion()
{
    return posicionJugador;
}

// DIRECCION HACIA DONDE MIRA LA CAMARA
glm::vec3 JugadorObtenerFrente()
{
    glm::vec3 frente;

    frente.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    frente.y = sin(glm::radians(pitch));
    frente.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

    return glm::normalize(frente);
}

bool JugadorMouseBloqueado()
{
    return mouseBloqueado;
}

// ---- VIDA ----
float JugadorObtenerVida()
{
    return vidaJugador;
}

float JugadorVidaMaxima()
{
    return vidaMaxima;
}

bool JugadorEstaVivo()
{
    return vidaJugador > 0.0f;
}

void JugadorRecibirDano(float cantidad)
{
    if (vidaJugador <= 0.0f)
        return;

    vidaJugador -= cantidad;

    if (vidaJugador < 0.0f)
        vidaJugador = 0.0f;

    destelloDano = 1.0f;
}

void JugadorCurar(float cantidad)
{
    if (vidaJugador <= 0.0f)
        return;

    vidaJugador += cantidad;

    if (vidaJugador > vidaMaxima)
        vidaJugador = vidaMaxima;
}

float JugadorObtenerDestelloDano()
{
    return destelloDano;
}

void JugadorActualizar(float deltaTime)
{
    destelloDano -= deltaTime * 2.5f;

    if (destelloDano < 0.0f)
        destelloDano = 0.0f;
}

void JugadorReiniciar()
{
    posicionJugador = glm::vec3(JUGADOR_INICIO_X, 1.5f, JUGADOR_INICIO_Z);
    yaw = -90.0f;
    pitch = 0.0f;
    velocidadVertical = 0.0f;
    enSuelo = true;
    vidaJugador = vidaMaxima;
    destelloDano = 0.0f;
}
