#ifndef AZAR_H
#define AZAR_H

#include <random>
#include <chrono>

// Numero aleatorio entre minimo y maximo
inline float Azar(float minimo, float maximo)
{
    static std::mt19937 generador(
        (unsigned int)std::chrono::steady_clock::now()
            .time_since_epoch().count()
    );

    std::uniform_real_distribution<float> distribucion(minimo, maximo);

    return distribucion(generador);
}

#endif
