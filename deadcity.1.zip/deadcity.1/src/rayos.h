#ifndef RAYOS_H
#define RAYOS_H

#include <glm/glm.hpp>
#include <algorithm>
#include <cmath>

// Interseccion rayo contra caja alineada a los ejes (metodo "slab").
// Devuelve true si el rayo la toca; "distancia" es la distancia al impacto.
inline bool RayoContraCaja(
    const glm::vec3& origen,
    const glm::vec3& direccion,
    const glm::vec3& minimo,
    const glm::vec3& maximo,
    float& distancia
)
{
    float tMin = 0.0f;
    float tMax = 1.0e9f;

    for (int eje = 0; eje < 3; eje++)
    {
        if (std::abs(direccion[eje]) < 1.0e-6f)
        {
            // Rayo paralelo a este eje: debe estar dentro de la caja
            if (origen[eje] < minimo[eje] || origen[eje] > maximo[eje])
                return false;
        }
        else
        {
            float inv = 1.0f / direccion[eje];
            float t1 = (minimo[eje] - origen[eje]) * inv;
            float t2 = (maximo[eje] - origen[eje]) * inv;

            if (t1 > t2)
                std::swap(t1, t2);

            tMin = std::max(tMin, t1);
            tMax = std::min(tMax, t2);

            if (tMin > tMax)
                return false;
        }
    }

    distancia = tMin;
    return true;
}

#endif
