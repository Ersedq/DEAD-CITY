#ifndef OBJETOS_H
#define OBJETOS_H

#include <glm/glm.hpp>

// Coleccionables: botiquin (vida) y caja de municion.
// Aparecen solos cada cierto tiempo y los zombis a veces los sueltan al morir.

// Borra todos los objetos y reinicia el temporizador
void ObjetosReiniciar();

// Hace aparecer objetos y detecta cuando el jugador los recoge
void ObjetosActualizar(float deltaTime, glm::vec3 posicionJugador);

void ObjetosDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
);

// Un zombi muerto puede soltar un objeto (probabilidad de 0 a 1)
void ObjetosSoltar(glm::vec3 posicion, float probabilidad);

// ---- AVISO PARA EL HUD ("+35 VIDA", "+MUNICION") ----
const char* ObjetosMensaje();

// 0 a 1 (baja con el tiempo; 0 = no mostrar)
float ObjetosMensajeTiempo();

#endif
