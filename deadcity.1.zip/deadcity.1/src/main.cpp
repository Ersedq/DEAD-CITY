
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>

#include "mundo.h"
#include "jugador.h"
#include "zombis.h"
#include "arma.h"
#include "hud.h"
#include "objetos.h"
#include "extraccion.h"
#include "escenario.h"

GLuint miraVAO = 0;
GLuint miraVBO = 0;
GLuint miraShader = 0;

void Redimensionar(GLFWwindow* window, int ancho, int alto)
{    
    glViewport(0, 0, ancho, alto);
}

GLuint MiraCrearShader(GLenum tipo, const char* fuente)
{
    GLuint shader = glCreateShader(tipo);
    glShaderSource(shader, 1, &fuente, nullptr);
    glCompileShader(shader);

    GLint correcto;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &correcto);

    if (!correcto)
    {
        char mensaje[512];
        glGetShaderInfoLog(shader, 512, nullptr, mensaje);
        std::cout << "Error shader mira: " << mensaje << std::endl;
        glDeleteShader(shader);
        return 0;
    }

    return shader;
}

bool MiraInicializar()
{
    const char* vertexSource = R"(
        #version 330 core

        layout (location = 0) in vec2 posicion;

        uniform vec2 resolucion;

        void main()
        {
            vec2 posicionFinal = posicion * 2.0 / resolucion;
            gl_Position = vec4(posicionFinal, 0.0, 1.0);
        }
    )";

    const char* fragmentSource = R"(
        #version 330 core

        out vec4 FragColor;

        void main()
        {
            FragColor = vec4(1.0, 1.0, 1.0, 1.0);
        }
    )";

    GLuint vertex = MiraCrearShader(GL_VERTEX_SHADER, vertexSource);
    GLuint fragment = MiraCrearShader(GL_FRAGMENT_SHADER, fragmentSource);

    if (vertex == 0 || fragment == 0)
        return false;

    miraShader = glCreateProgram();

    glAttachShader(miraShader, vertex);
    glAttachShader(miraShader, fragment);
    glLinkProgram(miraShader);

    GLint correcto;
    glGetProgramiv(miraShader, GL_LINK_STATUS, &correcto);

    glDeleteShader(vertex);
    glDeleteShader(fragment);

    if (!correcto)
    {
        char mensaje[512];
        glGetProgramInfoLog(miraShader, 512, nullptr, mensaje);
        std::cout << "Error al enlazar mira: " << mensaje << std::endl;
        return false;
    }

    float vertices[] =
    {
        -9.0f,  0.0f,
        -3.0f,  0.0f,

         3.0f,  0.0f,
         9.0f,  0.0f,

         0.0f, -9.0f,
         0.0f, -3.0f,

         0.0f,  3.0f,
         0.0f,  9.0f
    };

    glGenVertexArrays(1, &miraVAO);
    glGenBuffers(1, &miraVBO);

    glBindVertexArray(miraVAO);
    glBindBuffer(GL_ARRAY_BUFFER, miraVBO);

    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(vertices),
        vertices,
        GL_STATIC_DRAW
    );

    glVertexAttribPointer(
        0, 2, GL_FLOAT, GL_FALSE,
        2 * sizeof(float), (void*)0
    );

    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    return true;
}

void DibujarMira(int ancho, int alto)
{
    glDisable(GL_DEPTH_TEST);

    glUseProgram(miraShader);

    GLint resolucion = glGetUniformLocation(
        miraShader, "resolucion"
    );

    glUniform2f(resolucion, (float)ancho, (float)alto);

    glBindVertexArray(miraVAO);

    glLineWidth(2.0f);
    glDrawArrays(GL_LINES, 0, 8);

    glBindVertexArray(0);
    glUseProgram(0);

    glEnable(GL_DEPTH_TEST);
}


// ESTADO DE LA PARTIDA
enum class EstadoJuego
{
    JUGANDO,
    GAME_OVER,
    VICTORIA
};

// ---------------- AJUSTES DEL PUNTAJE ----------------
static const float TIEMPO_OBJETIVO    = 480.0f;  // si ganas antes de 8 minutos hay bono de tiempo
static const int   PUNTOS_POR_SEGUNDO = 5;       // bono por cada segundo que sobra
static const int   PUNTOS_POR_VIDA    = 10;      // bono por cada punto de vida al extraerte
// -----------------------------------------------------

static float tiempoPartida = 0.0f;        // segundos jugados
static float avisoExtraccion = 0.0f;      // segundos que dura el cartel "LLEGA A LA ZONA"

static int bonoTiempo = 0;
static int bonoVida = 0;
static int puntajeFinal = 0;
static int mejorPuntaje = 0;              // mejor puntaje mientras el juego este abierto
static bool nuevoRecord = false;

// "125" segundos -> "02:05"
static std::string FormatoTiempo(float segundos)
{
    int total = (int)segundos;

    char texto[16];
    std::snprintf(texto, sizeof(texto), "%02d:%02d", total / 60, total % 60);

    return std::string(texto);
}

void ReiniciarPartida(EstadoJuego& estado)
{
    JugadorReiniciar();
    ArmaReiniciar();
    ZombisReiniciar();
    ObjetosReiniciar();
    ExtraccionReiniciar();

    tiempoPartida = 0.0f;
    avisoExtraccion = 0.0f;
    bonoTiempo = 0;
    bonoVida = 0;
    puntajeFinal = 0;
    nuevoRecord = false;

    estado = EstadoJuego::JUGANDO;
}

// Calcula el puntaje al terminar la partida (ganando o perdiendo)
static void CerrarPartida(EstadoJuego resultado)
{
    puntajeFinal = ZombisPuntos();

    if (resultado == EstadoJuego::VICTORIA)
    {
        int segundosSobrantes = (int)(TIEMPO_OBJETIVO - tiempoPartida);

        bonoTiempo = std::max(0, segundosSobrantes) * PUNTOS_POR_SEGUNDO;
        bonoVida = (int)std::ceil(JugadorObtenerVida()) * PUNTOS_POR_VIDA;

        puntajeFinal += bonoTiempo + bonoVida;
    }

    nuevoRecord = puntajeFinal > mejorPuntaje;

    if (nuevoRecord)
        mejorPuntaje = puntajeFinal;
}

// DIBUJAR VIDA, MUNICION, OLEADAS Y PANTALLAS FINALES
void DibujarHud(int ancho, int alto, EstadoJuego estado)
{
    // "u" escala todo segun el tamano de la ventana (720 px de alto = 1.0)
    float u = (float)alto / 720.0f;

    float centroX = (float)ancho * 0.5f;
    float centroY = (float)alto * 0.5f;

    HudComenzar(ancho, alto);

    // ---- DESTELLO ROJO AL RECIBIR DANO ----
    float destello = JugadorObtenerDestelloDano();

    if (destello > 0.0f)
        HudRect(0, 0, (float)ancho, (float)alto,
            glm::vec4(0.8f, 0.0f, 0.0f, destello * 0.35f));

    // ---- BORDE ROJO CUANDO QUEDA POCA VIDA ----
    float vida = JugadorObtenerVida();
    float vidaMax = JugadorVidaMaxima();
    float proporcion = vida / vidaMax;

    if (proporcion < 0.3f && vida > 0.0f)
    {
        float latido = 0.5f + 0.5f * std::sin((float)glfwGetTime() * 6.0f);
        float grosor = 30.0f * u;
        glm::vec4 rojo(0.7f, 0.0f, 0.0f, 0.20f + 0.20f * latido);

        HudRect(0, 0, (float)ancho, grosor, rojo);
        HudRect(0, (float)alto - grosor, (float)ancho, grosor, rojo);
        HudRect(0, 0, grosor, (float)alto, rojo);
        HudRect((float)ancho - grosor, 0, grosor, (float)alto, rojo);
    }

    // ---- BARRA DE VIDA (abajo a la izquierda) ----
    {
        float x = 28.0f * u;
        float anchoBarra = 320.0f * u;
        float altoBarra = 26.0f * u;
        float y = (float)alto - 48.0f * u;

        HudTexto("VIDA " + std::to_string((int)std::ceil(vida)),
            x, y - 32.0f * u, 3.0f * u, glm::vec4(1, 1, 1, 0.95f));

        // Marco y fondo
        HudRect(x - 3.0f * u, y - 3.0f * u,
            anchoBarra + 6.0f * u, altoBarra + 6.0f * u,
            glm::vec4(0, 0, 0, 0.65f));

        HudRect(x, y, anchoBarra, altoBarra,
            glm::vec4(0.15f, 0.15f, 0.15f, 0.85f));

        // Relleno: pasa de verde a rojo
        glm::vec4 colorVida(
            1.0f - proporcion * 0.85f,
            0.15f + proporcion * 0.75f,
            0.10f,
            0.95f
        );

        HudRect(x, y, anchoBarra * std::max(0.0f, proporcion), altoBarra,
            colorVida);
    }

    // ---- MUNICION Y ARMA (abajo a la derecha) ----
    {
        float margen = 28.0f * u;
        float derecha = (float)ancho - margen;

        std::string nombre = ArmaNombre(ArmaActual());

        std::string balas =
            std::to_string(ArmaCargador()) + " / " +
            std::to_string(ArmaReserva());

        float escalaBalas = 5.0f * u;
        float escalaNombre = 3.0f * u;

        glm::vec4 colorBalas(1, 1, 1, 0.95f);

        if (ArmaCargador() == 0 && ArmaReserva() == 0)
            colorBalas = glm::vec4(1.0f, 0.25f, 0.2f, 1.0f);

        float yBalas = (float)alto - 48.0f * u - 6.0f * u;

        HudTexto(balas,
            derecha - HudAnchoTexto(balas, escalaBalas),
            yBalas, escalaBalas, colorBalas);

        HudTexto(nombre,
            derecha - HudAnchoTexto(nombre, escalaNombre),
            yBalas - 30.0f * u, escalaNombre, glm::vec4(1, 0.85f, 0.4f, 0.95f));

        if (ArmaRecargando())
        {
            std::string texto = "RECARGANDO";
            float escala = 3.0f * u;
            float yTexto = yBalas - 62.0f * u;

            HudTexto(texto,
                derecha - HudAnchoTexto(texto, escala),
                yTexto, escala, glm::vec4(1, 1, 0.4f, 1));

            // Barra de progreso de recarga
            float anchoRec = HudAnchoTexto(texto, escala);

            HudRect(derecha - anchoRec, yTexto + 28.0f * u,
                anchoRec, 6.0f * u, glm::vec4(0, 0, 0, 0.6f));

            HudRect(derecha - anchoRec, yTexto + 28.0f * u,
                anchoRec * ArmaProgresoRecarga(), 6.0f * u,
                glm::vec4(1, 1, 0.4f, 0.95f));
        }

        // Selector de armas: 1 PISTOLA  2 RIFLE  3 ESCOPETA
        float xSel = centroX - 200.0f * u;

        for (int i = 0; i < 3; i++)
        {
            std::string etiqueta =
                std::to_string(i + 1) + " " + ArmaNombre(i);

            glm::vec4 color = (i == ArmaActual())
                ? glm::vec4(1.0f, 0.85f, 0.4f, 1.0f)
                : glm::vec4(0.6f, 0.6f, 0.6f, 0.7f);

            HudTexto(etiqueta, xSel, (float)alto - 30.0f * u, 2.0f * u, color);

            xSel += HudAnchoTexto(etiqueta, 2.0f * u) + 24.0f * u;
        }
    }

    // ---- TIEMPO, BAJAS Y PUNTOS (arriba a los lados) ----
    {
        std::string tiempo = "TIEMPO " + FormatoTiempo(tiempoPartida);

        HudTexto(tiempo, 28.0f * u, 20.0f * u, 2.5f * u,
            glm::vec4(1, 1, 1, 0.85f));

        std::string bajas = "BAJAS " + std::to_string(ZombisEliminados());

        HudTexto(bajas,
            (float)ancho - 28.0f * u - HudAnchoTexto(bajas, 2.5f * u),
            20.0f * u, 2.5f * u, glm::vec4(1, 1, 1, 0.8f));

        std::string puntos = "PUNTOS " + std::to_string(ZombisPuntos());

        HudTexto(puntos,
            (float)ancho - 28.0f * u - HudAnchoTexto(puntos, 2.5f * u),
            52.0f * u, 2.5f * u, glm::vec4(1.0f, 0.85f, 0.4f, 0.95f));
    }

    // ---- OLEADA O EXTRACCION (arriba al centro) ----
    if (!ExtraccionActiva())
    {
        int oleada = ZombisOleadaActual();

        if (ZombisPausaOleada() > 0.0f)
            oleada += 1;

        oleada = std::min(oleada, ZombisOleadasTotales());

        std::string titulo =
            "OLEADA " + std::to_string(oleada) + "/" +
            std::to_string(ZombisOleadasTotales());

        HudTextoCentrado(titulo, 18.0f * u, 3.5f * u,
            glm::vec4(1, 1, 1, 0.95f));

        std::string restantes =
            "ZOMBIS " + std::to_string(ZombisRestantes());

        HudTextoCentrado(restantes, 56.0f * u, 2.5f * u,
            glm::vec4(0.6f, 1.0f, 0.5f, 0.95f));

        // Aviso grande entre oleadas
        if (estado == EstadoJuego::JUGANDO && ZombisPausaOleada() > 0.0f)
        {
            HudTextoCentrado(
                "OLEADA " + std::to_string(oleada),
                (float)alto * 0.22f, 9.0f * u,
                glm::vec4(1.0f, 0.3f, 0.2f, 0.9f));

            HudTextoCentrado(
                "PREPARATE",
                (float)alto * 0.22f + 90.0f * u, 3.0f * u,
                glm::vec4(1, 1, 1, 0.8f));
        }
    }
    else
    {
        HudTextoCentrado("EXTRACCION", 18.0f * u, 3.5f * u,
            glm::vec4(0.4f, 1.0f, 0.5f, 0.95f));

        std::string distancia =
            "ZONA A " +
            std::to_string((int)ExtraccionDistancia(JugadorObtenerPosicion())) +
            " M";

        HudTextoCentrado(distancia, 56.0f * u, 2.5f * u,
            glm::vec4(1, 1, 1, 0.9f));

        std::string restantes =
            "ZOMBIS " + std::to_string(ZombisRestantes());

        HudTextoCentrado(restantes, 86.0f * u, 2.0f * u,
            glm::vec4(0.6f, 1.0f, 0.5f, 0.8f));

        // Cartel grande cuando se abre la zona
        if (estado == EstadoJuego::JUGANDO && avisoExtraccion > 0.0f)
        {
            float a = std::min(1.0f, avisoExtraccion);

            HudTextoCentrado("OLEADAS SUPERADAS", (float)alto * 0.20f, 6.0f * u,
                glm::vec4(0.4f, 1.0f, 0.5f, a));

            HudTextoCentrado("LLEGA A LA ZONA DE EXTRACCION",
                (float)alto * 0.20f + 70.0f * u, 3.0f * u,
                glm::vec4(1, 1, 1, a));
        }

        // Barra de progreso dentro de la zona
        if (estado == EstadoJuego::JUGANDO && ExtraccionProgreso() > 0.0f)
        {
            float anchoBarra = 360.0f * u;
            float altoBarra = 22.0f * u;
            float x = centroX - anchoBarra * 0.5f;
            float y = (float)alto * 0.34f;

            HudTextoCentrado("EXTRAYENDO", y - 36.0f * u, 3.0f * u,
                glm::vec4(0.4f, 1.0f, 0.5f, 1.0f));

            HudRect(x - 3.0f * u, y - 3.0f * u,
                anchoBarra + 6.0f * u, altoBarra + 6.0f * u,
                glm::vec4(0, 0, 0, 0.65f));

            HudRect(x, y, anchoBarra * ExtraccionProgreso(), altoBarra,
                glm::vec4(0.4f, 1.0f, 0.5f, 0.95f));
        }
    }

    // ---- AVISO AL RECOGER UN OBJETO ----
    {
        float m = ObjetosMensajeTiempo();

        if (m > 0.0f && estado == EstadoJuego::JUGANDO)
        {
            HudTextoCentrado(ObjetosMensaje(),
                (float)alto * 0.58f - (1.0f - m) * 24.0f * u,
                3.5f * u, glm::vec4(0.7f, 1.0f, 0.6f, std::min(1.0f, m * 2.0f)));
        }
    }

    // ---- MARCA DE IMPACTO ALREDEDOR DE LA MIRA ----
    {
        float m = ArmaMarcadorImpacto();

        if (m > 0.0f && estado == EstadoJuego::JUGANDO)
        {
            glm::vec4 color = ArmaMarcadorMuerte()
                ? glm::vec4(1.0f, 0.15f, 0.15f, m)
                : glm::vec4(1.0f, 1.0f, 1.0f, m);

            float t = 3.0f;      // tamano del cuadrito
            float d = 13.0f;     // distancia al centro

            HudRect(centroX - d, centroY - d, t, t, color);
            HudRect(centroX + d - t, centroY - d, t, t, color);
            HudRect(centroX - d, centroY + d - t, t, t, color);
            HudRect(centroX + d - t, centroY + d - t, t, t, color);
        }
    }

    // ---- AVISO SI EL RATON ESTA LIBRE ----
    if (estado == EstadoJuego::JUGANDO && !JugadorMouseBloqueado())
    {
        HudTextoCentrado("CLIC PARA CONTINUAR", (float)alto * 0.62f,
            3.0f * u, glm::vec4(1, 1, 1, 0.85f));
    }

    // ---- PANTALLAS FINALES ----
    if (estado == EstadoJuego::GAME_OVER || estado == EstadoJuego::VICTORIA)
    {
        bool gano = (estado == EstadoJuego::VICTORIA);

        float y0 = (float)alto * 0.14f;      // inicio del bloque de texto
        float paso = 38.0f * u;              // separacion entre lineas

        HudRect(0, 0, (float)ancho, (float)alto,
            gano ? glm::vec4(0.0f, 0.25f, 0.05f, 0.65f)
                 : glm::vec4(0.35f, 0.0f, 0.0f, 0.65f));

        HudTextoCentrado(
            gano ? "EXTRACCION COMPLETADA" : "GAME OVER",
            y0, gano ? 7.0f * u : 13.0f * u,
            gano ? glm::vec4(0.3f, 1.0f, 0.4f, 1.0f)
                 : glm::vec4(1.0f, 0.15f, 0.15f, 1.0f));

        float y = y0 + (gano ? 90.0f * u : 130.0f * u);
        glm::vec4 blanco(1, 1, 1, 0.95f);

        if (!gano)
        {
            HudTextoCentrado(
                "LLEGASTE A LA OLEADA " + std::to_string(ZombisOleadaActual()),
                y, 3.0f * u, blanco);
            y += paso;
        }

        HudTextoCentrado("TIEMPO " + FormatoTiempo(tiempoPartida),
            y, 3.0f * u, blanco);
        y += paso;

        HudTextoCentrado("BAJAS " + std::to_string(ZombisEliminados()),
            y, 3.0f * u, blanco);
        y += paso;

        HudTextoCentrado("PUNTOS POR ZOMBIS " + std::to_string(ZombisPuntos()),
            y, 3.0f * u, blanco);
        y += paso;

        if (gano)
        {
            HudTextoCentrado("BONO DE TIEMPO +" + std::to_string(bonoTiempo),
                y, 3.0f * u, glm::vec4(0.6f, 1.0f, 0.5f, 0.95f));
            y += paso;

            HudTextoCentrado("BONO DE VIDA +" + std::to_string(bonoVida),
                y, 3.0f * u, glm::vec4(0.6f, 1.0f, 0.5f, 0.95f));
            y += paso;
        }

        y += 10.0f * u;

        HudTextoCentrado("PUNTAJE FINAL " + std::to_string(puntajeFinal),
            y, 4.5f * u, glm::vec4(1.0f, 0.85f, 0.4f, 1.0f));
        y += paso + 14.0f * u;

        if (nuevoRecord)
        {
            HudTextoCentrado("NUEVO RECORD!", y, 3.0f * u,
                glm::vec4(1.0f, 0.85f, 0.4f, 1.0f));
        }
        else
        {
            HudTextoCentrado("MEJOR PUNTAJE " + std::to_string(mejorPuntaje),
                y, 3.0f * u, glm::vec4(1, 1, 1, 0.7f));
        }

        HudTextoCentrado(
            gano ? "PRESIONA R PARA JUGAR OTRA VEZ" : "PRESIONA R PARA REINICIAR",
            (float)alto * 0.86f, 3.0f * u,
            glm::vec4(1.0f, 0.85f, 0.4f, 1.0f));
    }

    HudTerminar();
}


int main()
{
    // INICIALIZAR GLFW
    if (!glfwInit())
    {
        std::cout << "Error al iniciar GLFW\n";
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // CREAR VENTANA
    GLFWwindow* window = glfwCreateWindow(
        1280, 720,
        "DEAD CITY - Zombie Survival",
        nullptr, nullptr
    );

    if (!window)
    {
        std::cout << "Error al crear ventana\n";
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);

    glfwSetFramebufferSizeCallback(window, Redimensionar);

    // INICIALIZAR GLEW
    if (glewInit() != GLEW_OK)
    {
        std::cout << "Error al iniciar GLEW\n";
        glfwDestroyWindow(window);
        glfwTerminate();
        return -1;
    }

    glEnable(GL_DEPTH_TEST);

    if (!MiraInicializar())
    {
        std::cout << "No se pudo inicializar la mira." << std::endl;
        return -1;
    }

    if (!HudInicializar())
    {
        std::cout << "No se pudo inicializar el HUD." << std::endl;
        return -1;
    }

    int ancho, alto;

    glfwGetFramebufferSize(window, &ancho, &alto);
    glViewport(0, 0, ancho, alto);

    // INICIALIZAR MUNDO Y JUGADOR
    MundoInicializar();

    JugadorInicializar(window);

    // ESTADO DE LA PARTIDA (zombis, armas, objetos y extraccion)
    EstadoJuego estado = EstadoJuego::JUGANDO;
    ReiniciarPartida(estado);

    std::cout << "DEAD CITY INICIADO CORRECTAMENTE\n";

    // CONTROL DEL TIEMPO
    float tiempoAnterior = (float)glfwGetTime();

    bool rAnterior = false;

    // BUCLE PRINCIPAL
    while (!glfwWindowShouldClose(window))
    {
        float tiempoActual = (float)glfwGetTime();

        float deltaTime = tiempoActual - tiempoAnterior;

        tiempoAnterior = tiempoActual;

        // EVITAR SALTOS GRANDES DE TIEMPO
        if (deltaTime > 0.05f)
            deltaTime = 0.05f;

        // R se detecta una sola vez por pulsacion (recargar y reiniciar usan la misma tecla)
        bool rPulsada = glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS;
        bool rNueva = rPulsada && !rAnterior;
        rAnterior = rPulsada;

        // ARMAS (clic = disparar, R = recargar, 1/2/3 = cambiar arma)
        bool puedeActuar =
            estado == EstadoJuego::JUGANDO && JugadorMouseBloqueado();

        ArmaActualizar(window, deltaTime, puedeActuar);

        // PROCESAR CONTROLES
        JugadorProcesarEntrada(window, deltaTime);
        JugadorActualizar(deltaTime);

        // TIEMPO DE PARTIDA (solo corre mientras juegas)
        if (estado == EstadoJuego::JUGANDO)
            tiempoPartida += deltaTime;

        // ZOMBIS Y OLEADAS (al ganar se congelan para que no te sigan atacando)
        if (estado != EstadoJuego::VICTORIA)
            ZombisActualizar(deltaTime, JugadorObtenerPosicion());

        // OBJETOS, EXTRACCION Y FIN DE LA PARTIDA
        if (estado == EstadoJuego::JUGANDO)
        {
            glm::vec3 posicionJugador = JugadorObtenerPosicion();

            ObjetosActualizar(deltaTime, posicionJugador);

            // Al vencer la ultima oleada se abre la zona de extraccion
            if (ZombisOleadasCompletadas() && !ExtraccionActiva())
            {
                ExtraccionActivar();
                ZombisActivarRefuerzos();
                avisoExtraccion = 4.0f;
            }

            ExtraccionActualizar(deltaTime, posicionJugador);

            avisoExtraccion = std::max(0.0f, avisoExtraccion - deltaTime);

            if (!JugadorEstaVivo())
            {
                estado = EstadoJuego::GAME_OVER;
                CerrarPartida(estado);
            }
            else if (ExtraccionCompletada())
            {
                estado = EstadoJuego::VICTORIA;
                CerrarPartida(estado);
            }
        }
        else if (rNueva)
        {
            ReiniciarPartida(estado);
        }

        // OBTENER CAMARA DEL JUGADOR
        glm::mat4 vista = JugadorObtenerVista();

        // ACTUALIZAR TAMAÑO DE VENTANA
        glfwGetFramebufferSize(window, &ancho, &alto);

        if (alto == 0 || ancho == 0)
        {
            glfwPollEvents();
            continue;
        }

        // LIMPIAR PANTALLA
        glClearColor(0.025f, 0.035f, 0.065f, 1.0f);

        glClear(
            GL_COLOR_BUFFER_BIT |
            GL_DEPTH_BUFFER_BIT
        );

        // PROYECCION
        glm::mat4 proyeccion = glm::perspective(
            glm::radians(60.0f),
            (float)ancho / (float)alto,
            0.1f,
            100.0f
        );

        // DIBUJAR MUNDO
        MundoDibujar(vista, proyeccion);

        // DIBUJAR ZONA DE EXTRACCION Y OBJETOS
        ExtraccionDibujar(vista, proyeccion);
        ObjetosDibujar(vista, proyeccion);

        // DIBUJAR ZOMBIS
        ZombisDibujar(vista, proyeccion);

        // DIBUJAR ARMA EN PRIMERA PERSONA
        if (JugadorEstaVivo())
            ArmaDibujar(vista, proyeccion);

        // DIBUJAR PUNTO DE MIRA
        if (estado == EstadoJuego::JUGANDO)
            DibujarMira(ancho, alto);

        // DIBUJAR VIDA, MUNICION, OLEADAS Y PANTALLAS FINALES
        DibujarHud(ancho, alto, estado);

        // ACTUALIZAR PANTALLA
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &miraVAO);
    glDeleteBuffers(1, &miraVBO);
    glDeleteProgram(miraShader);
    HudLiberar();

    // LIBERAR RECURSOS
    MundoLiberar();

    glfwDestroyWindow(window);

    glfwTerminate();

    return 0;
}
