#ifndef ESCENARIO_H
#define ESCENARIO_H

// DATOS UNICOS DEL ESCENARIO
// Mundo.cpp los usa para DIBUJAR y Jugador.cpp para las COLISIONES,
// asi nunca se desfasan. Si mueves un edificio, solo cambias este archivo.

#include <glm/glm.hpp>
#include <iterator>

// ---- LIMITES DEL MAPA ----
// El suelo mide 40 x 40 (de -20 a +20). Una pared rodea el mapa.
static const float MAPA_MITAD      = 20.0f;
static const float LIMITE_MOVIMIENTO = 19.4f;   // hasta donde puede llegar un cuerpo

// ---- POSICION INICIAL DEL JUGADOR (mirando hacia -Z, hacia la extraccion) ----
static const float JUGADOR_INICIO_X = 0.0f;
static const float JUGADOR_INICIO_Z = 17.5f;

// ---- ZONA DE EXTRACCION (cuadrado sobre la carretera, al fondo de la calle) ----
static const float EXTRACCION_X     = 0.0f;
static const float EXTRACCION_Z     = -16.0f;
static const float EXTRACCION_MITAD = 3.2f;     // la zona mide 6.4 x 6.4

// ---- EDIFICIOS ----
static const float BASE_EDIFICIOS = -0.25f;     // el suelo termina en Y = -0.25

struct EdificioDatos
{
    glm::vec2 centro;   // X, Z
    glm::vec2 mitad;    // mitad del ancho (X) y del largo (Z)
    float altura;
    glm::vec3 color;
};

inline const EdificioDatos EDIFICIOS[] =
{
    // IZQUIERDOS
    { glm::vec2(-11.0f, -10.0f), glm::vec2(2.5f, 2.5f), 6.0f, glm::vec3(0.35f, 0.28f, 0.25f) },
    { glm::vec2(-12.0f,   0.0f), glm::vec2(2.0f, 3.0f), 8.0f, glm::vec3(0.40f, 0.35f, 0.30f) },
    { glm::vec2(-11.0f,  12.0f), glm::vec2(3.0f, 2.5f), 4.0f, glm::vec3(0.30f, 0.32f, 0.35f) },

    // DERECHOS
    { glm::vec2( 11.0f, -12.0f), glm::vec2(2.5f, 3.0f), 8.0f, glm::vec3(0.38f, 0.30f, 0.26f) },
    { glm::vec2( 12.0f,   0.0f), glm::vec2(2.0f, 2.5f), 6.0f, glm::vec3(0.32f, 0.34f, 0.38f) },
    { glm::vec2( 11.0f,  13.0f), glm::vec2(3.0f, 2.5f), 4.0f, glm::vec3(0.40f, 0.28f, 0.25f) }
};

static const int EDIFICIOS_TOTAL = (int)std::size(EDIFICIOS);

// ---- FAROLAS (X, Z) ----
inline const glm::vec2 FAROLAS[] =
{
    glm::vec2(-7.2f, -14.0f), glm::vec2(-7.2f,  0.0f), glm::vec2(-7.2f, 14.0f),
    glm::vec2( 7.2f, -14.0f), glm::vec2( 7.2f,  0.0f), glm::vec2( 7.2f, 14.0f)
};

static const int FAROLAS_TOTAL = (int)std::size(FAROLAS);

// ---- BARRILES (X, Z) ----
inline const glm::vec2 BARRILES[] =
{
    glm::vec2(-6.5f, -12.0f),
    glm::vec2( 6.5f,  10.0f),
    glm::vec2(-6.5f,  17.0f)
};

static const int BARRILES_TOTAL = (int)std::size(BARRILES);

// ---- GRUPOS DE ESCOMBROS (X, Z) ----
inline const glm::vec2 ESCOMBROS[] =
{
    glm::vec2(-6.5f, -19.0f), glm::vec2(-6.5f, -5.0f),
    glm::vec2(-6.5f,   7.0f), glm::vec2(-6.5f, 19.0f),
    glm::vec2( 6.5f, -19.0f), glm::vec2( 6.5f, -5.0f),
    glm::vec2( 6.5f,   7.0f), glm::vec2( 6.5f, 19.0f)
};

static const int ESCOMBROS_TOTAL = (int)std::size(ESCOMBROS);

#endif
