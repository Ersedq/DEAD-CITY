#ifndef JUGADOR_H
#define JUGADOR_H

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

void JugadorInicializar(GLFWwindow* ventana);

void JugadorProcesarEntrada(
    GLFWwindow* ventana,
    float deltaTime
);

glm::mat4 JugadorObtenerVista();

glm::vec3 JugadorObtenerPosicion();

// Hacia donde mira la camara (vector unitario)
glm::vec3 JugadorObtenerFrente();

// El raton esta capturado por el juego (no se pulso ESC)
bool JugadorMouseBloqueado();

// ---- VIDA ----
float JugadorObtenerVida();
float JugadorVidaMaxima();
void JugadorRecibirDano(float cantidad);
void JugadorCurar(float cantidad);
bool JugadorEstaVivo();

// Intensidad (0 a 1) del destello rojo tras recibir dano
float JugadorObtenerDestelloDano();

// Actualiza temporizadores del jugador (destello de dano)
void JugadorActualizar(float deltaTime);

// Vuelve a la posicion inicial con vida completa
void JugadorReiniciar();

// ---- COLISIONES (las usan los zombis y las balas) ----
// true si el cuerpo (circulo en XZ) cabe en esa posicion
bool PuedeMoverse(glm::vec3 posicion);

// Distancia hasta el primer edificio que cruza el rayo (o distanciaMax si ninguno)
float DistanciaRayoEdificios(
    glm::vec3 origen,
    glm::vec3 direccion,
    float distanciaMax
);

#endif