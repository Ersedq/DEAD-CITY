
#include "zombis.h"
#include "jugador.h"
#include "arma.h"
#include "mundo.h"
#include "rayos.h"
#include "azar.h"
#include "escenario.h"
#include "objetos.h"

#include <glm/gtc/matrix_transform.hpp>

#include <vector>
#include <cmath>
#include <algorithm>

// ---------------- AJUSTES DEL JUEGO (cambia estos numeros a tu gusto) ----------------
static const int   OLEADAS_TOTALES      = 3;      // oleadas para ganar
static const int   ZOMBIS_OLEADA_BASE   = 4;      // zombis en la oleada 1
static const int   ZOMBIS_EXTRA_OLEADA  = 3;      // zombis extra por cada oleada nueva
static const float VIDA_ZOMBI           = 100.0f;
static const float DANO_ZOMBI_BASE      = 8.0f;   // dano por golpe (sube +2 por oleada)
static const float VELOCIDAD_BASE       = 1.8f;   // el jugador camina a 6 y corre a 11
static const float PAUSA_ENTRE_OLEADAS  = 5.0f;   // segundos de descanso
static const float CURACION_OLEADA      = 30.0f;  // vida que recuperas al pasar de oleada
static const float INTERVALO_REFUERZOS  = 3.0f;   // en la extraccion llegan refuerzos cada tanto
static const int   MAXIMO_REFUERZOS     = 6;      // zombis vivos maximos durante la extraccion
static const int   BONO_CABEZA          = 50;     // puntos extra por matar de un tiro en la cabeza
static const float DISTANCIA_APARICION  = 18.0f;  // minima distancia al jugador al aparecer
// --------------------------------------------------------------------------------------

static const float PIES_Y         = -0.12f;  // altura del suelo donde pisan
static const float ALTURA_ZOMBI   = 1.85f;
static const float RANGO_ATAQUE   = 1.15f;
static const float PI             = 3.14159265f;

// TIPOS DE ZOMBI
enum TipoZombi
{
    ZOMBI_NORMAL,
    ZOMBI_CORREDOR,    // rapido, poca vida (aparece desde la oleada 2)
    ZOMBI_TANQUE       // lento, enorme y muy resistente (aparece desde la oleada 3)
};

struct Zombi
{
    int tipo;
    float escala;          // tamano del cuerpo (1 = normal)
    float multiplicadorDano;
    int puntos;            // puntos al eliminarlo
    glm::vec3 pos;
    float vida;
    float angulo;
    float velocidad;
    float enfriamientoAtaque;
    float golpe;           // animacion de ataque (1 -> 0)
    float animacion;       // fase de la caminata
    float destello;        // brillo rojo al recibir un disparo
    float tiempoMuerto;
    bool muerto;
    int variante;          // color de ropa
};

static std::vector<Zombi> zombis;

static int   oleada = 0;
static int   porAparecer = 0;
static float temporizadorAparicion = 0.0f;
static float pausaOleada = 0.0f;
static int   eliminados = 0;
static int   puntos = 0;
static bool  oleadasCompletadas = false;   // se vencieron todas las oleadas
static bool  refuerzos = false;            // durante la extraccion siguen llegando zombis

// ---------------------------------------------------------------------------

static int ContarVivos()
{
    int vivos = 0;

    for (const Zombi& z : zombis)
    {
        if (!z.muerto)
            vivos++;
    }

    return vivos;
}

static void CrearZombi(glm::vec3 posicion)
{
    Zombi z;

    // Elegir el tipo segun la oleada
    float sorteo = Azar(0.0f, 1.0f);
    float probTanque = (oleada >= 3) ? 0.20f : 0.0f;
    float probCorredor = (oleada >= 2) ? 0.28f : 0.0f;

    z.tipo = ZOMBI_NORMAL;

    if (sorteo < probTanque)
        z.tipo = ZOMBI_TANQUE;
    else if (sorteo < probTanque + probCorredor)
        z.tipo = ZOMBI_CORREDOR;

    float velocidad = VELOCIDAD_BASE
        + Azar(0.0f, 0.8f)
        + 0.25f * (float)(oleada - 1);

    z.pos = posicion;
    z.vida = VIDA_ZOMBI;
    z.escala = 1.0f;
    z.multiplicadorDano = 1.0f;
    z.puntos = 100;

    if (z.tipo == ZOMBI_CORREDOR)
    {
        z.vida = 55.0f;
        velocidad *= 1.7f;
        z.escala = 0.9f;
        z.multiplicadorDano = 0.7f;
        z.puntos = 150;
    }
    else if (z.tipo == ZOMBI_TANQUE)
    {
        z.vida = 280.0f;
        velocidad *= 0.65f;
        z.escala = 1.35f;
        z.multiplicadorDano = 2.0f;
        z.puntos = 300;
    }

    z.angulo = 0.0f;
    z.velocidad = velocidad;
    z.enfriamientoAtaque = 0.6f;
    z.golpe = 0.0f;
    z.animacion = Azar(0.0f, 6.0f);
    z.destello = 0.0f;
    z.tiempoMuerto = 0.0f;
    z.muerto = false;
    z.variante = (int)Azar(0.0f, 2.999f);

    zombis.push_back(z);
}

// Busca un lugar libre y lejos del jugador para que aparezca un zombi
static void AparecerZombi(glm::vec3 jugador)
{
    for (int intento = 0; intento < 40; intento++)
    {
        float x = Azar(-5.5f, 5.5f);
        float z = Azar(-19.0f, 19.0f);

        glm::vec3 posicion(x, PIES_Y, z);

        float dx = x - jugador.x;
        float dz = z - jugador.z;

        if (dx * dx + dz * dz < DISTANCIA_APARICION * DISTANCIA_APARICION)
            continue;

        if (!PuedeMoverse(posicion))
            continue;

        CrearZombi(posicion);
        return;
    }

    // Plan B: el extremo lejano de la calle
    CrearZombi(glm::vec3(Azar(-3.0f, 3.0f), PIES_Y, -19.0f));
}

static void IniciarOleada(int numero)
{
    oleada = numero;

    porAparecer = ZOMBIS_OLEADA_BASE + ZOMBIS_EXTRA_OLEADA * (numero - 1);
    temporizadorAparicion = 0.0f;

    // Recompensa por sobrevivir a la oleada anterior
    if (numero > 1)
    {
        JugadorCurar(CURACION_OLEADA);
        ArmaRecompensaOleada();
    }
}

void ZombisReiniciar()
{
    zombis.clear();

    oleada = 0;
    porAparecer = 0;
    temporizadorAparicion = 0.0f;
    pausaOleada = 2.5f;      // pequeña pausa antes de la oleada 1
    eliminados = 0;
    puntos = 0;
    oleadasCompletadas = false;
    refuerzos = false;
}

// Intenta mover un zombi (primero en X y luego en Z, como el jugador)
static bool IntentarMover(Zombi& z, glm::vec2 paso)
{
    bool movido = false;

    glm::vec3 nueva = z.pos;
    nueva.x += paso.x;

    if (PuedeMoverse(nueva))
    {
        z.pos.x = nueva.x;
        movido = true;
    }

    nueva = z.pos;
    nueva.z += paso.y;

    if (PuedeMoverse(nueva))
    {
        z.pos.z = nueva.z;
        movido = true;
    }

    return movido;
}

static glm::vec2 Rotar(glm::vec2 v, float radianes)
{
    float c = std::cos(radianes);
    float s = std::sin(radianes);

    return glm::vec2(v.x * c - v.y * s, v.x * s + v.y * c);
}

static void MoverHaciaJugador(Zombi& z, glm::vec2 direccion, float distancia)
{
    glm::vec2 paso = direccion * distancia;

    // Si choca con un edificio u objeto, prueba rodearlo
    if (!IntentarMover(z, paso))
    {
        if (!IntentarMover(z, Rotar(paso, 1.0f)))
            IntentarMover(z, Rotar(paso, -1.0f));
    }
}   // los limites del mapa los controla PuedeMoverse()

void ZombisActualizar(float deltaTime, glm::vec3 posicionJugador)
{
    // ---------- CONTROL DE OLEADAS ----------
    if (!oleadasCompletadas)
    {
        if (pausaOleada > 0.0f)
        {
            pausaOleada -= deltaTime;

            if (pausaOleada <= 0.0f)
            {
                pausaOleada = 0.0f;
                IniciarOleada(oleada + 1);
            }
        }
        else
        {
            // Van apareciendo de uno en uno
            if (porAparecer > 0)
            {
                temporizadorAparicion -= deltaTime;

                if (temporizadorAparicion <= 0.0f)
                {
                    AparecerZombi(posicionJugador);
                    porAparecer--;
                    temporizadorAparicion = 1.2f;
                }
            }
            else if (oleada >= 1 && ContarVivos() == 0)
            {
                // Oleada terminada
                if (oleada >= OLEADAS_TOTALES)
                {
                    oleadasCompletadas = true;
                    temporizadorAparicion = INTERVALO_REFUERZOS;
                }
                else
                    pausaOleada = PAUSA_ENTRE_OLEADAS;
            }
        }
    }
    else if (refuerzos)
    {
        // EXTRACCION: siguen llegando zombis mientras corres hacia la zona
        temporizadorAparicion -= deltaTime;

        if (temporizadorAparicion <= 0.0f && ContarVivos() < MAXIMO_REFUERZOS)
        {
            AparecerZombi(posicionJugador);
            temporizadorAparicion = INTERVALO_REFUERZOS;
        }
    }

    // ---------- COMPORTAMIENTO DE CADA ZOMBI ----------
    for (Zombi& z : zombis)
    {
        z.destello = std::max(0.0f, z.destello - deltaTime * 4.0f);

        if (z.muerto)
        {
            z.tiempoMuerto += deltaTime;
            continue;
        }

        z.enfriamientoAtaque = std::max(0.0f, z.enfriamientoAtaque - deltaTime);
        z.golpe = std::max(0.0f, z.golpe - deltaTime * 3.0f);

        glm::vec2 hacia(
            posicionJugador.x - z.pos.x,
            posicionJugador.z - z.pos.z
        );

        float distancia = glm::length(hacia);

        if (distancia > 0.001f)
        {
            hacia /= distancia;
            z.angulo = std::atan2(hacia.x, hacia.y);
        }

        float rango = RANGO_ATAQUE + 0.3f * (z.escala - 1.0f);

        if (distancia > rango)
        {
            MoverHaciaJugador(z, hacia, z.velocidad * deltaTime);
            z.animacion += deltaTime * z.velocidad * 3.2f;
        }
        else if (z.enfriamientoAtaque <= 0.0f && posicionJugador.y < 2.5f)
        {
            // Ataque (si saltas muy alto, te esquiva)
            JugadorRecibirDano(
                (DANO_ZOMBI_BASE + 2.0f * (float)(oleada - 1))
                * z.multiplicadorDano
            );

            z.enfriamientoAtaque = 0.9f;
            z.golpe = 1.0f;
        }
    }

    // ---------- SEPARAR ZOMBIS PARA QUE NO SE ATRAVIESEN ----------
    for (size_t i = 0; i < zombis.size(); i++)
    {
        if (zombis[i].muerto)
            continue;

        for (size_t j = i + 1; j < zombis.size(); j++)
        {
            if (zombis[j].muerto)
                continue;

            glm::vec2 d(
                zombis[i].pos.x - zombis[j].pos.x,
                zombis[i].pos.z - zombis[j].pos.z
            );

            float dist = glm::length(d);

            if (dist >= 0.9f)
                continue;

            if (dist < 0.001f)
            {
                d = glm::vec2(1.0f, 0.0f);
                dist = 1.0f;
            }

            glm::vec2 empuje = (d / dist) * ((0.9f - dist) * 0.5f);

            IntentarMover(zombis[i], empuje);
            IntentarMover(zombis[j], -empuje);
        }
    }

    // ---------- QUITAR CADAVERES VIEJOS ----------
    zombis.erase(
        std::remove_if(
            zombis.begin(), zombis.end(),
            [](const Zombi& z) { return z.muerto && z.tiempoMuerto > 2.5f; }
        ),
        zombis.end()
    );
}

// ---------------------------------------------------------------------------
//  DIBUJO
// ---------------------------------------------------------------------------

static void Parte(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    const glm::mat4& modelo,
    const glm::vec3& escala,
    const glm::vec3& color
)
{
    MundoDibujarCuboModelo(
        vista, proyeccion,
        glm::scale(modelo, escala),
        color
    );
}

static void DibujarZombi(
    const Zombi& z,
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    // Colores segun la variante de ropa
    const glm::vec3 camisas[3] =
    {
        glm::vec3(0.50f, 0.20f, 0.18f),
        glm::vec3(0.22f, 0.32f, 0.50f),
        glm::vec3(0.40f, 0.40f, 0.25f)
    };

    const glm::vec3 pantalones[3] =
    {
        glm::vec3(0.18f, 0.20f, 0.30f),
        glm::vec3(0.30f, 0.26f, 0.20f),
        glm::vec3(0.16f, 0.16f, 0.18f)
    };

    glm::vec3 piel(0.45f, 0.65f, 0.38f);
    glm::vec3 camisa = camisas[z.variante];
    glm::vec3 pantalon = pantalones[z.variante];

    if (z.tipo == ZOMBI_CORREDOR)
    {
        // Pálido y amarillento, con ropa rasgada clara
        piel = glm::vec3(0.72f, 0.64f, 0.30f);
        camisa = glm::vec3(0.55f, 0.50f, 0.42f);
    }
    else if (z.tipo == ZOMBI_TANQUE)
    {
        // Piel gris verdosa y camisa oscura manchada
        piel = glm::vec3(0.30f, 0.46f, 0.30f);
        camisa = glm::vec3(0.22f, 0.10f, 0.10f);
        pantalon = glm::vec3(0.10f, 0.10f, 0.12f);
    }

    // Destello rojo al recibir un disparo
    glm::vec3 rojo(2.2f, 0.25f, 0.25f);

    piel = glm::mix(piel, rojo, z.destello);
    camisa = glm::mix(camisa, rojo, z.destello);
    pantalon = glm::mix(pantalon, rojo, z.destello);

    // Matriz base: posicion + giro hacia el jugador (+ caida si esta muerto)
    float caida = 0.0f;

    if (z.muerto)
        caida = std::min(1.0f, z.tiempoMuerto / 0.5f);

    glm::mat4 base(1.0f);
    base = glm::translate(base, z.pos + glm::vec3(0.0f, caida * 0.15f, 0.0f));
    base = glm::rotate(base, z.angulo, glm::vec3(0.0f, 1.0f, 0.0f));
    base = glm::rotate(base, -caida * PI * 0.5f, glm::vec3(1.0f, 0.0f, 0.0f));
    base = glm::scale(base, glm::vec3(z.escala));

    // Movimiento de piernas y brazos
    float balanceo = z.muerto ? 0.0f : std::sin(z.animacion) * 0.6f;
    float ataque = std::sin(z.golpe * PI) * 0.7f;
    float temblor = z.muerto ? 0.0f : std::sin(z.animacion * 0.5f) * 0.08f;

    // Piernas (giran desde la cadera)
    for (int lado = -1; lado <= 1; lado += 2)
    {
        glm::mat4 pierna = glm::translate(
            base, glm::vec3(0.13f * lado, 0.80f, 0.0f)
        );

        pierna = glm::rotate(
            pierna, balanceo * (float)lado, glm::vec3(1.0f, 0.0f, 0.0f)
        );

        pierna = glm::translate(pierna, glm::vec3(0.0f, -0.40f, 0.0f));

        Parte(vista, proyeccion, pierna,
            glm::vec3(0.22f, 0.80f, 0.24f), pantalon);
    }

    // Torso
    Parte(vista, proyeccion,
        glm::translate(base, glm::vec3(0.0f, 1.10f, 0.0f)),
        glm::vec3(0.58f, 0.70f, 0.32f), camisa);

    // Brazos estirados hacia adelante (zombi clasico)
    for (int lado = -1; lado <= 1; lado += 2)
    {
        glm::mat4 brazo = glm::translate(
            base, glm::vec3(0.37f * lado, 1.32f, 0.0f)
        );

        brazo = glm::rotate(
            brazo, ataque + temblor, glm::vec3(1.0f, 0.0f, 0.0f)
        );

        brazo = glm::translate(brazo, glm::vec3(0.0f, 0.0f, 0.34f));

        Parte(vista, proyeccion, brazo,
            glm::vec3(0.15f, 0.15f, 0.70f), piel);
    }

    // Cabeza
    glm::mat4 cabeza = glm::translate(base, glm::vec3(0.0f, 1.66f, 0.04f));

    Parte(vista, proyeccion, cabeza,
        glm::vec3(0.38f, 0.38f, 0.38f), piel);

    // Ojos rojos brillantes (se ven en la oscuridad)
    if (!z.muerto)
    {
        for (int lado = -1; lado <= 1; lado += 2)
        {
            Parte(vista, proyeccion,
                glm::translate(cabeza, glm::vec3(0.09f * lado, 0.04f, 0.19f)),
                glm::vec3(0.07f, 0.05f, 0.03f),
                glm::vec3(4.0f, 0.25f, 0.15f));
        }
    }
}

void ZombisDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    for (const Zombi& z : zombis)
        DibujarZombi(z, vista, proyeccion);
}

// ---------------------------------------------------------------------------
//  DISPAROS
// ---------------------------------------------------------------------------

int ZombisDisparar(
    glm::vec3 origen,
    glm::vec3 direccion,
    float dano,
    float alcance
)
{
    // Los edificios bloquean las balas
    float mejorDistancia = DistanciaRayoEdificios(origen, direccion, alcance);

    int indice = -1;

    for (size_t i = 0; i < zombis.size(); i++)
    {
        const Zombi& z = zombis[i];

        if (z.muerto)
            continue;

        float ancho = 0.32f * z.escala;

        glm::vec3 minimo(z.pos.x - ancho, z.pos.y, z.pos.z - ancho);
        glm::vec3 maximo(z.pos.x + ancho, z.pos.y + ALTURA_ZOMBI * z.escala, z.pos.z + ancho);

        float d;

        if (RayoContraCaja(origen, direccion, minimo, maximo, d)
            && d < mejorDistancia)
        {
            mejorDistancia = d;
            indice = (int)i;
        }
    }

    if (indice < 0)
        return 0;

    Zombi& z = zombis[indice];

    // Punto de impacto: si es en la cabeza, dano doble
    glm::vec3 impacto = origen + direccion * mejorDistancia;

    bool cabeza = impacto.y > z.pos.y + 1.45f * z.escala;

    if (cabeza)
        dano *= 2.0f;

    z.vida -= dano;
    z.destello = 1.0f;

    if (z.vida <= 0.0f)
    {
        z.muerto = true;
        z.tiempoMuerto = 0.0f;
        eliminados++;

        puntos += z.puntos + (cabeza ? BONO_CABEZA : 0);

        // A veces suelta un botiquin o municion (el tanque casi siempre)
        ObjetosSoltar(z.pos, (z.tipo == ZOMBI_TANQUE) ? 0.7f : 0.12f);

        return 2;
    }

    return 1;
}

// ---------------------------------------------------------------------------

int ZombisOleadaActual()
{
    return oleada;
}

int ZombisOleadasTotales()
{
    return OLEADAS_TOTALES;
}

int ZombisRestantes()
{
    return ContarVivos() + porAparecer;
}

int ZombisEliminados()
{
    return eliminados;
}

float ZombisPausaOleada()
{
    return pausaOleada;
}

int ZombisPuntos()
{
    return puntos;
}

// true cuando se vencen todas las oleadas (despues hay que extraerse)
bool ZombisOleadasCompletadas()
{
    return oleadasCompletadas;
}

// Durante la extraccion siguen llegando zombis
void ZombisActivarRefuerzos()
{
    refuerzos = true;
    temporizadorAparicion = INTERVALO_REFUERZOS;
}
