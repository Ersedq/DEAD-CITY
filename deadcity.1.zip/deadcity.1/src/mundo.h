
#ifndef MUNDO_H
#define MUNDO_H

#include <glm/glm.hpp>

// Inicializar los recursos del escenario
void MundoInicializar();

// Dibujar el escenario 3D
void MundoDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
);

// Dibuja un cubo con una matriz de modelo completa (posicion, rotacion y escala).
// Lo usan los zombis y el arma para tener la misma iluminacion nocturna.
void MundoDibujarCuboModelo(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    const glm::mat4& modelo,
    const glm::vec3& color
);

// Liberar recursos
void MundoLiberar();

#endif

