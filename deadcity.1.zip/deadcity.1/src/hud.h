#ifndef HUD_H
#define HUD_H

#include <glm/glm.hpp>
#include <string>

// Dibujo 2D encima de la escena: rectangulos y texto con fuente de pixeles.
// Las coordenadas estan en pixeles, con el origen (0,0) arriba a la izquierda.

bool HudInicializar();
void HudLiberar();

// Llamar antes y despues de dibujar el HUD (activa / desactiva transparencia)
void HudComenzar(int ancho, int alto);
void HudTerminar();

void HudRect(float x, float y, float ancho, float alto, glm::vec4 color);

void HudTexto(
    const std::string& texto,
    float x, float y,
    float escala,
    glm::vec4 color
);

float HudAnchoTexto(const std::string& texto, float escala);

// Texto centrado horizontalmente en la pantalla
void HudTextoCentrado(
    const std::string& texto,
    float y,
    float escala,
    glm::vec4 color
);

#endif
