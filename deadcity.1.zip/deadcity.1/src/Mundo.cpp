
#include "mundo.h"
#include "escenario.h"

#include <GL/glew.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GLFW/glfw3.h>

#include <iostream>
#include <vector>
#include <string>

GLuint VAO, VBO, shaderProgram;

// Ubicaciones de los uniforms (se buscan una sola vez, no en cada cubo)
static GLint ubMVP = -1;
static GLint ubModelo = -1;
static GLint ubColor = -1;
static GLint ubTiempo = -1;
static float ultimoTiempoEnviado = -1.0f;

// Geometría de un cubo
float vertices[] = {
    // Frente
    -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f,0.5f,0.5f,
    -0.5f,-0.5f, 0.5f,  0.5f,0.5f,0.5f,  -0.5f,0.5f,0.5f,

    // Atrás
    0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f,
    0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,

    // Izquierda
    -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f,
    -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,

    // Derecha
    0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f,
    0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,

    // Arriba
    -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f,
    -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,

    // Abajo
    -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f,
    -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
};

// Crear shader
GLuint CrearShader(GLenum tipo, const char* codigo)
{
    GLuint shader = glCreateShader(tipo);
    glShaderSource(shader, 1, &codigo, nullptr);
    glCompileShader(shader);

    GLint correcto;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &correcto);

    if (!correcto)
    {
        char mensaje[512];
        glGetShaderInfoLog(shader, 512, nullptr, mensaje);
        std::cout << "Error shader: " << mensaje << std::endl;
    }

    return shader;
}



// El shader tiene un arreglo fijo de 6 luces (luces[6])
static_assert(FAROLAS_TOTAL == 6, "El shader espera 6 farolas");

void MundoInicializar()
{
    // VERTEX SHADER
    const char* vertexShader = R"(
    #version 330 core

    layout (location = 0) in vec3 posicion;

    uniform mat4 mvp;
    uniform mat4 modelo;

    out vec3 posicionMundo;

    void main()
    {
        vec4 posicionGlobal = modelo * vec4(posicion, 1.0);

        posicionMundo = posicionGlobal.xyz;

        gl_Position = mvp * vec4(posicion, 1.0);
    }
    )";

    // FRAGMENT SHADER: NOCHE, FAROLAS Y NIEBLA
    const char* fragmentShader = R"(
    #version 330 core

    in vec3 posicionMundo;

    out vec4 FragColor;

    uniform vec3 colorObjeto;
    uniform vec3 luces[6];
    uniform float tiempo;

    void main()
    {
        // Iluminacion ambiental nocturna
        vec3 iluminacion = vec3(0.13, 0.15, 0.19);

        // Luces amarillas de las farolas
        for (int i = 0; i < 6; i++)
        {
            float distancia = length(posicionMundo - luces[i]);

            float atenuacion = max(0.0, 1.0 - distancia / 9.0);

            atenuacion *= atenuacion;

             float parpadeo = 0.82 + 0.18 *
             sin(tiempo * 8.0 + float(i) * 3.7);

             iluminacion += vec3(1.0, 0.72, 0.40)
             * atenuacion * 1.8 * parpadeo;
        }

        vec3 colorFinal = colorObjeto * iluminacion;

        // Niebla nocturna
        vec3 colorNiebla = vec3(0.035, 0.05, 0.075);

        float profundidad = gl_FragCoord.z;

        float intensidadNiebla = smoothstep(
            0.992,
            0.9995,
            profundidad
        );

        colorFinal = mix(
            colorFinal,
            colorNiebla,
            intensidadNiebla
        );

        FragColor = vec4(colorFinal, 1.0);
    }
    )";

    // CREAR SHADERS
    GLuint vertex = CrearShader(GL_VERTEX_SHADER, vertexShader);
    GLuint fragment = CrearShader(GL_FRAGMENT_SHADER, fragmentShader);

    // CREAR PROGRAMA
    shaderProgram = glCreateProgram();

    glAttachShader(shaderProgram, vertex);
    glAttachShader(shaderProgram, fragment);

    glLinkProgram(shaderProgram);

    GLint resultado;

    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &resultado);

    if (!resultado)
    {
        char mensaje[512];

        glGetProgramInfoLog(
            shaderProgram, 512, nullptr, mensaje
        );

        std::cout << "ERROR AL VINCULAR SHADERS: "
                  << mensaje << std::endl;
    }

    glDeleteShader(vertex);
    glDeleteShader(fragment);

    // GUARDAR UBICACIONES DE LOS UNIFORMS
    ubMVP = glGetUniformLocation(shaderProgram, "mvp");
    ubModelo = glGetUniformLocation(shaderProgram, "modelo");
    ubColor = glGetUniformLocation(shaderProgram, "colorObjeto");
    ubTiempo = glGetUniformLocation(shaderProgram, "tiempo");

    // LAS LUCES NO CAMBIAN: se envian una sola vez (salen de las farolas)
    float posicionesLuces[FAROLAS_TOTAL * 3];

    for (int i = 0; i < FAROLAS_TOTAL; i++)
    {
        // La lampara cuelga 0.85 hacia el centro de la calle
        float desvio = (FAROLAS[i].x < 0.0f) ? 0.85f : -0.85f;

        posicionesLuces[i * 3 + 0] = FAROLAS[i].x + desvio;
        posicionesLuces[i * 3 + 1] = 4.40f;
        posicionesLuces[i * 3 + 2] = FAROLAS[i].y;
    }

    glUseProgram(shaderProgram);

    glUniform3fv(
        glGetUniformLocation(shaderProgram, "luces[0]"),
        FAROLAS_TOTAL,
        posicionesLuces
    );

    // CREAR VAO Y VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(vertices),
        vertices,
        GL_STATIC_DRAW
    );

    glVertexAttribPointer(
        0,
        3,
        GL_FLOAT,
        GL_FALSE,
        3 * sizeof(float),
        (void*)0
    );

    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    std::cout << "Mundo nocturno inicializado correctamente."
              << std::endl;
}




void MundoDibujarCuboModelo(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    const glm::mat4& modelo,
    const glm::vec3& color
)
{
    glm::mat4 mvp = proyeccion * vista * modelo;

    glUseProgram(shaderProgram);

    // El tiempo solo se envia cuando cambia (una vez por cuadro)
    float tiempo = (float)glfwGetTime();

    if (tiempo != ultimoTiempoEnviado)
    {
        glUniform1f(ubTiempo, tiempo);
        ultimoTiempoEnviado = tiempo;
    }

    glUniformMatrix4fv(ubMVP, 1, GL_FALSE, glm::value_ptr(mvp));
    glUniformMatrix4fv(ubModelo, 1, GL_FALSE, glm::value_ptr(modelo));
    glUniform3fv(ubColor, 1, glm::value_ptr(color));

    glBindVertexArray(VAO);

    glDrawArrays(GL_TRIANGLES, 0, 36);
}

void DibujarCubo(
    glm::mat4 vista,
    glm::mat4 proyeccion,
    glm::vec3 posicion,
    glm::vec3 escala,
    glm::vec3 color
)
{
    glm::mat4 modelo = glm::mat4(1.0f);

    modelo = glm::translate(modelo, posicion);
    modelo = glm::scale(modelo, escala);

    MundoDibujarCuboModelo(vista, proyeccion, modelo, color);
}

void DibujarEdificio(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    glm::vec3 ubicacion,
    glm::vec3 dimensiones,
    glm::vec3 color
)
{
    // El suelo termina en Y = -0.25
    float base = -0.25f;
    float altura = dimensiones.y;

    // Centro del edificio: apoyado en el suelo
    glm::vec3 centro(
        ubicacion.x,
        base + altura / 2.0f,
        ubicacion.z
    );

    // Cuerpo principal
    DibujarCubo(
        vista, proyeccion,
        centro,
        dimensiones,
        color
    );

    // Fachada frontal: lado que mira hacia Z positivo
    float frente = ubicacion.z + dimensiones.z / 2.0f + 0.06f;

    // Ventanas
    for (int fila = 0; fila < 2; fila++)
    {
        float y = base + altura * (fila == 0 ? 0.35f : 0.70f);

        for (int columna = 0; columna < 2; columna++)
        {
            float x = ubicacion.x +
                (columna == 0 ? -dimensiones.x * 0.22f : dimensiones.x * 0.22f);

            // Cristal oscuro
            DibujarCubo(
                vista, proyeccion,
                glm::vec3(x, y, frente),
                glm::vec3(0.85f, 1.0f, 0.10f),
                glm::vec3(0.08f, 0.13f, 0.17f)
            );
        }
    }

    // Puerta de entrada
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(ubicacion.x, base + 0.90f, frente + 0.02f),
        glm::vec3(1.0f, 1.8f, 0.12f),
        glm::vec3(0.18f, 0.10f, 0.07f)
    );
}

void DibujarFarola(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    float x,
    float z
)
{
    // Poste vertical
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 2.25f, z),
        glm::vec3(0.10f, 2.5f, 0.10f),
        glm::vec3(0.12f, 0.12f, 0.13f)
    );

    // Brazo horizontal
    float direccion = (x < 0) ? 1.0f : -1.0f;

    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x + direccion * 0.40f, 4.55f, z),
        glm::vec3(0.50f, 0.08f, 0.08f),
        glm::vec3(0.12f, 0.12f, 0.13f)
    );

    // Lámpara amarillenta
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x + direccion * 0.85f, 4.40f, z),
        glm::vec3(0.35f, 0.15f, 0.25f),
        glm::vec3(0.95f, 0.78f, 0.35f)
    );
}

void DibujarEscombros(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    float x,
    float z
)
{
    // Caja de cartón
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 0.12f, z),
        glm::vec3(0.35f, 0.19f, 0.35f),
        glm::vec3(0.38f, 0.23f, 0.12f)
    );

    // Bolsa de basura
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x + 0.55f, 0.08f, z + 0.25f),
        glm::vec3(0.30f, 0.15f, 0.28f),
        glm::vec3(0.08f, 0.09f, 0.10f)
    );

    // Piedra grande
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x - 0.45f, 0.02f, z + 0.45f),
        glm::vec3(0.20f, 0.08f, 0.16f),
        glm::vec3(0.35f, 0.34f, 0.32f)
    );

    // Piedra pequeña
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x + 0.25f, 0.01f, z - 0.45f),
        glm::vec3(0.12f, 0.06f, 0.12f),
        glm::vec3(0.28f, 0.27f, 0.25f)
    );
}


void DibujarBarril(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    float x,
    float z
)
{
    // Cuerpo del barril
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 0.55f, z),
        glm::vec3(0.38f, 0.55f, 0.38f),
        glm::vec3(0.35f, 0.16f, 0.10f)
    );

    // Aro superior
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 1.08f, z),
        glm::vec3(0.40f, 0.06f, 0.40f),
        glm::vec3(0.18f, 0.18f, 0.17f)
    );

    // Aro inferior
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 0.12f, z),
        glm::vec3(0.40f, 0.06f, 0.40f),
        glm::vec3(0.18f, 0.18f, 0.17f)
    );
}

void DibujarMancha(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    float x,
    float z
)
{
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, -0.105f, z),
        glm::vec3(0.75f, 0.015f, 0.55f),
        glm::vec3(0.055f, 0.045f, 0.04f)
    );
}

void DibujarSenal(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    float x,
    float z
)
{
    // Poste
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 1.1f, z),
        glm::vec3(0.07f, 1.1f, 0.07f),
        glm::vec3(0.18f, 0.18f, 0.17f)
    );

    // Placa amarilla
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(x, 2.15f, z),
        glm::vec3(0.65f, 0.40f, 0.08f),
        glm::vec3(0.85f, 0.65f, 0.12f)
    );
}


void MundoDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    // SUELO
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(0.0f, -0.5f, 0.0f),
        glm::vec3(40.0f, 0.5f, 40.0f),
        glm::vec3(0.25f, 0.30f, 0.22f)
    );

    // CARRETERA
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(0.0f, -0.20f, 0.0f),
        glm::vec3(5.0f, 0.08f, 40.0f),
        glm::vec3(0.10f, 0.10f, 0.12f)
    );

    // VEREDA IZQUIERDA
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(-6.8f, -0.16f, 0.0f),
        glm::vec3(1.3f, 0.09f, 40.0f),
        glm::vec3(0.42f, 0.42f, 0.40f)
    );

    // VEREDA DERECHA
    DibujarCubo(
        vista, proyeccion,
        glm::vec3(6.8f, -0.16f, 0.0f),
        glm::vec3(1.3f, 0.09f, 40.0f),
        glm::vec3(0.42f, 0.42f, 0.40f)
    );

    // PARED QUE RODEA EL MAPA (los limites de movimiento estan justo antes)
    {
        const glm::vec3 colorPared(0.16f, 0.15f, 0.15f);
        float largo = MAPA_MITAD * 2.0f + 1.2f;
        float centroPared = MAPA_MITAD + 0.3f;

        DibujarCubo(vista, proyeccion,
            glm::vec3(0.0f, 1.25f, -centroPared),
            glm::vec3(largo, 3.0f, 0.6f), colorPared);

        DibujarCubo(vista, proyeccion,
            glm::vec3(0.0f, 1.25f, centroPared),
            glm::vec3(largo, 3.0f, 0.6f), colorPared);

        DibujarCubo(vista, proyeccion,
            glm::vec3(-centroPared, 1.25f, 0.0f),
            glm::vec3(0.6f, 3.0f, largo), colorPared);

        DibujarCubo(vista, proyeccion,
            glm::vec3(centroPared, 1.25f, 0.0f),
            glm::vec3(0.6f, 3.0f, largo), colorPared);
    }

    // FAROLAS
    for (int i = 0; i < FAROLAS_TOTAL; i++)
        DibujarFarola(vista, proyeccion, FAROLAS[i].x, FAROLAS[i].y);

    // EDIFICIOS
    for (int i = 0; i < EDIFICIOS_TOTAL; i++)
    {
        const EdificioDatos& e = EDIFICIOS[i];

        DibujarEdificio(vista, proyeccion,
            glm::vec3(e.centro.x, 0.0f, e.centro.y),
            glm::vec3(e.mitad.x * 2.0f, e.altura, e.mitad.y * 2.0f),
            e.color);
    }

    // ESCOMBROS
    for (int i = 0; i < ESCOMBROS_TOTAL; i++)
        DibujarEscombros(vista, proyeccion, ESCOMBROS[i].x, ESCOMBROS[i].y);

    // BARRILES OXIDADOS
    for (int i = 0; i < BARRILES_TOTAL; i++)
        DibujarBarril(vista, proyeccion, BARRILES[i].x, BARRILES[i].y);

    // MANCHAS EN EL SUELO
    DibujarMancha(vista, proyeccion, -3.0f, -8.0f);
    DibujarMancha(vista, proyeccion, 3.0f, 5.0f);
    DibujarMancha(vista, proyeccion, 0.0f, 16.0f);

    // SEÑALES DE PELIGRO
    DibujarSenal(vista, proyeccion, -7.0f, -18.5f);
    DibujarSenal(vista, proyeccion, 7.0f, 18.5f);
}

void MundoLiberar()
{
    glDeleteBuffers(1, &VBO);
    glDeleteVertexArrays(1, &VAO);
    glDeleteProgram(shaderProgram);

    std::cout << "Recursos del mundo liberados." << std::endl;
}