
#include "objetos.h"
#include "jugador.h"
#include "arma.h"
#include "mundo.h"
#include "azar.h"

#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>

#include <vector>
#include <cmath>
#include <algorithm>

// ---------------- AJUSTES (cambia estos numeros a tu gusto) ----------------
static const float INTERVALO_MIN        = 12.0f;  // segundos entre apariciones
static const float INTERVALO_MAX        = 20.0f;
static const float PRIMERA_APARICION    = 8.0f;   // el primero sale rapido
static const int   MAXIMO_EN_MAPA       = 3;      // objetos a la vez (sin contar los soltados)
static const float DURACION_OBJETO      = 30.0f;  // segundos antes de desaparecer
static const float RADIO_RECOGER        = 1.3f;
static const float CURACION_BOTIQUIN    = 35.0f;
static const float FACTOR_MUNICION      = 0.6f;   // 1.0 = reserva inicial completa
static const float DURACION_MENSAJE     = 1.6f;
// ---------------------------------------------------------------------------

enum class TipoObjeto
{
    VIDA,
    MUNICION
};

struct Objeto
{
    glm::vec3 pos;
    TipoObjeto tipo;
    float edad;        // segundos desde que aparecio
};

static std::vector<Objeto> objetos;

static float temporizadorAparicion = PRIMERA_APARICION;

static const char* mensaje = "";
static float tiempoMensaje = 0.0f;

static const float PI = 3.14159265f;

// ---------------------------------------------------------------------------

// Si el jugador esta herido, es mas probable que salga un botiquin
static TipoObjeto ElegirTipo()
{
    float proporcion = JugadorObtenerVida() / JugadorVidaMaxima();

    float probabilidadVida = (proporcion < 0.5f) ? 0.65f : 0.40f;

    return (Azar(0.0f, 1.0f) < probabilidadVida)
        ? TipoObjeto::VIDA
        : TipoObjeto::MUNICION;
}

static void AparecerObjeto()
{
    glm::vec3 jugador = JugadorObtenerPosicion();

    for (int intento = 0; intento < 40; intento++)
    {
        float x = Azar(-7.5f, 7.5f);
        float z = Azar(-18.0f, 18.0f);

        glm::vec3 posicion(x, 0.0f, z);

        // No sale pegado al jugador (hay que ir a buscarlo)
        float dx = x - jugador.x;
        float dz = z - jugador.z;

        if (dx * dx + dz * dz < 6.0f * 6.0f)
            continue;

        if (!PuedeMoverse(posicion))
            continue;

        objetos.push_back({ posicion, ElegirTipo(), 0.0f });
        return;
    }
}

void ObjetosReiniciar()
{
    objetos.clear();

    temporizadorAparicion = PRIMERA_APARICION;

    mensaje = "";
    tiempoMensaje = 0.0f;
}

void ObjetosSoltar(glm::vec3 posicion, float probabilidad)
{
    if (Azar(0.0f, 1.0f) > probabilidad)
        return;

    posicion.y = 0.0f;

    objetos.push_back({ posicion, ElegirTipo(), 0.0f });
}

static void Recoger(const Objeto& objeto)
{
    if (objeto.tipo == TipoObjeto::VIDA)
    {
        JugadorCurar(CURACION_BOTIQUIN);
        mensaje = "+35 VIDA";
    }
    else
    {
        ArmaAgregarMunicion(FACTOR_MUNICION);
        mensaje = "+MUNICION";
    }

    tiempoMensaje = DURACION_MENSAJE;
}

void ObjetosActualizar(float deltaTime, glm::vec3 posicionJugador)
{
    tiempoMensaje = std::max(0.0f, tiempoMensaje - deltaTime);

    // ---------- APARICION AUTOMATICA ----------
    temporizadorAparicion -= deltaTime;

    if (temporizadorAparicion <= 0.0f)
    {
        temporizadorAparicion = Azar(INTERVALO_MIN, INTERVALO_MAX);

        if ((int)objetos.size() < MAXIMO_EN_MAPA)
            AparecerObjeto();
    }

    // ---------- ENVEJECER, RECOGER Y QUITAR ----------
    for (size_t i = 0; i < objetos.size(); )
    {
        Objeto& o = objetos[i];

        o.edad += deltaTime;

        bool recogido = false;

        float dx = posicionJugador.x - o.pos.x;
        float dz = posicionJugador.z - o.pos.z;

        bool cerca = dx * dx + dz * dz < RADIO_RECOGER * RADIO_RECOGER
            && posicionJugador.y < 3.5f;

        if (cerca)
        {
            // Con la vida llena el botiquin se queda esperando
            bool vidaLlena = o.tipo == TipoObjeto::VIDA
                && JugadorObtenerVida() >= JugadorVidaMaxima();

            if (!vidaLlena)
            {
                Recoger(o);
                recogido = true;
            }
        }

        if (recogido || o.edad >= DURACION_OBJETO)
            objetos.erase(objetos.begin() + (long)i);
        else
            i++;
    }
}

// ---------------------------------------------------------------------------
//  DIBUJO
// ---------------------------------------------------------------------------

static void Parte(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    const glm::mat4& modelo,
    const glm::vec3& posicion,
    const glm::vec3& escala,
    const glm::vec3& color
)
{
    MundoDibujarCuboModelo(
        vista, proyeccion,
        glm::scale(glm::translate(modelo, posicion), escala),
        color
    );
}

static void DibujarObjeto(
    const Objeto& o,
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    float t = (float)glfwGetTime();

    // Parpadea cuando le queda poco tiempo
    float restante = DURACION_OBJETO - o.edad;

    if (restante < 6.0f && std::fmod(t * 6.0f, 1.0f) < 0.45f)
        return;

    float flota = 0.65f + 0.10f * std::sin(t * 3.0f + o.pos.x);

    glm::mat4 base(1.0f);
    base = glm::translate(base, glm::vec3(o.pos.x, flota, o.pos.z));
    base = glm::rotate(base, t * 1.8f, glm::vec3(0.0f, 1.0f, 0.0f));

    // El escenario es muy oscuro: los colores se aclaran para que se vean
    if (o.tipo == TipoObjeto::VIDA)
    {
        // Botiquin: caja blanca con cruz roja
        Parte(vista, proyeccion, base, glm::vec3(0.0f),
            glm::vec3(0.40f, 0.40f, 0.40f), glm::vec3(4.0f, 4.0f, 4.0f));

        Parte(vista, proyeccion, base, glm::vec3(0.0f),
            glm::vec3(0.26f, 0.08f, 0.44f), glm::vec3(5.0f, 0.2f, 0.2f));

        Parte(vista, proyeccion, base, glm::vec3(0.0f),
            glm::vec3(0.08f, 0.26f, 0.44f), glm::vec3(5.0f, 0.2f, 0.2f));
    }
    else
    {
        // Caja de municion: caja verde oliva con balas doradas encima
        Parte(vista, proyeccion, base, glm::vec3(0.0f),
            glm::vec3(0.46f, 0.28f, 0.32f), glm::vec3(1.6f, 2.0f, 0.9f));

        for (int i = -1; i <= 1; i++)
        {
            Parte(vista, proyeccion, base,
                glm::vec3(0.12f * (float)i, 0.22f, 0.0f),
                glm::vec3(0.07f, 0.18f, 0.07f), glm::vec3(5.0f, 4.0f, 1.2f));
        }
    }

    // Columna de luz para encontrarlo de lejos (verde = vida, amarillo = municion)
    glm::vec3 luz = (o.tipo == TipoObjeto::VIDA)
        ? glm::vec3(0.4f, 9.0f, 1.2f)
        : glm::vec3(9.0f, 7.0f, 0.8f);

    MundoDibujarCuboModelo(
        vista, proyeccion,
        glm::scale(
            glm::translate(glm::mat4(1.0f), glm::vec3(o.pos.x, 1.6f, o.pos.z)),
            glm::vec3(0.05f, 2.4f, 0.05f)
        ),
        luz
    );
}

void ObjetosDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    for (const Objeto& o : objetos)
        DibujarObjeto(o, vista, proyeccion);
}

// ---------------------------------------------------------------------------

const char* ObjetosMensaje()
{
    return mensaje;
}

float ObjetosMensajeTiempo()
{
    return tiempoMensaje / DURACION_MENSAJE;
}
