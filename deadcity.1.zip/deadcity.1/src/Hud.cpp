
#include "hud.h"

#include <GL/glew.h>

#include <iostream>
#include <cctype>

static GLuint hudVAO = 0;
static GLuint hudVBO = 0;
static GLuint hudShader = 0;

static GLint ubRect = -1;
static GLint ubColor = -1;
static GLint ubResolucion = -1;

static int hudAncho = 1280;
static int hudAlto = 720;

// FUENTE DE PIXELES 5x7 (cada fila son 5 bits, el bit mas alto es la izquierda)
static const char* LETRAS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ/:.-!+ ";

static const unsigned char FUENTE[][7] =
{
    {0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E}, // '0'
    {0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E}, // '1'
    {0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F}, // '2'
    {0x0E, 0x11, 0x01, 0x06, 0x01, 0x11, 0x0E}, // '3'
    {0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02}, // '4'
    {0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E}, // '5'
    {0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E}, // '6'
    {0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08}, // '7'
    {0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E}, // '8'
    {0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C}, // '9'
    {0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11}, // 'A'
    {0x1E, 0x11, 0x11, 0x1E, 0x11, 0x11, 0x1E}, // 'B'
    {0x0E, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0E}, // 'C'
    {0x1E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1E}, // 'D'
    {0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F}, // 'E'
    {0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x10}, // 'F'
    {0x0E, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0F}, // 'G'
    {0x11, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11}, // 'H'
    {0x0E, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0E}, // 'I'
    {0x07, 0x02, 0x02, 0x02, 0x02, 0x12, 0x0C}, // 'J'
    {0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11}, // 'K'
    {0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1F}, // 'L'
    {0x11, 0x1B, 0x15, 0x15, 0x11, 0x11, 0x11}, // 'M'
    {0x11, 0x19, 0x15, 0x13, 0x11, 0x11, 0x11}, // 'N'
    {0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E}, // 'O'
    {0x1E, 0x11, 0x11, 0x1E, 0x10, 0x10, 0x10}, // 'P'
    {0x0E, 0x11, 0x11, 0x11, 0x15, 0x12, 0x0D}, // 'Q'
    {0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11}, // 'R'
    {0x0F, 0x10, 0x10, 0x0E, 0x01, 0x01, 0x1E}, // 'S'
    {0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04}, // 'T'
    {0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E}, // 'U'
    {0x11, 0x11, 0x11, 0x11, 0x11, 0x0A, 0x04}, // 'V'
    {0x11, 0x11, 0x11, 0x15, 0x15, 0x1B, 0x11}, // 'W'
    {0x11, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x11}, // 'X'
    {0x11, 0x11, 0x0A, 0x04, 0x04, 0x04, 0x04}, // 'Y'
    {0x1F, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1F}, // 'Z'
    {0x01, 0x01, 0x02, 0x04, 0x08, 0x10, 0x10}, // '/'
    {0x00, 0x04, 0x04, 0x00, 0x04, 0x04, 0x00}, // ':'
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x0C}, // '.'
    {0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00}, // '-'
    {0x04, 0x04, 0x04, 0x04, 0x04, 0x00, 0x04}, // '!'
    {0x00, 0x04, 0x04, 0x1F, 0x04, 0x04, 0x00}, // '+'
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // ' '
};

static GLuint HudCrearShader(GLenum tipo, const char* fuente)
{
    GLuint shader = glCreateShader(tipo);
    glShaderSource(shader, 1, &fuente, nullptr);
    glCompileShader(shader);

    GLint correcto;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &correcto);

    if (!correcto)
    {
        char mensaje[512];
        glGetShaderInfoLog(shader, 512, nullptr, mensaje);
        std::cout << "Error shader HUD: " << mensaje << std::endl;
        glDeleteShader(shader);
        return 0;
    }

    return shader;
}

bool HudInicializar()
{
    const char* vertexSource = R"(
        #version 330 core

        layout (location = 0) in vec2 esquina;

        uniform vec4 rect;          // x, y, ancho, alto (pixeles)
        uniform vec2 resolucion;

        void main()
        {
            vec2 pixel = rect.xy + esquina * rect.zw;

            gl_Position = vec4(
                pixel.x / resolucion.x * 2.0 - 1.0,
                1.0 - pixel.y / resolucion.y * 2.0,
                0.0,
                1.0
            );
        }
    )";

    const char* fragmentSource = R"(
        #version 330 core

        out vec4 FragColor;

        uniform vec4 color;

        void main()
        {
            FragColor = color;
        }
    )";

    GLuint vertex = HudCrearShader(GL_VERTEX_SHADER, vertexSource);
    GLuint fragment = HudCrearShader(GL_FRAGMENT_SHADER, fragmentSource);

    if (vertex == 0 || fragment == 0)
        return false;

    hudShader = glCreateProgram();
    glAttachShader(hudShader, vertex);
    glAttachShader(hudShader, fragment);
    glLinkProgram(hudShader);

    GLint correcto;
    glGetProgramiv(hudShader, GL_LINK_STATUS, &correcto);

    glDeleteShader(vertex);
    glDeleteShader(fragment);

    if (!correcto)
    {
        char mensaje[512];
        glGetProgramInfoLog(hudShader, 512, nullptr, mensaje);
        std::cout << "Error al enlazar HUD: " << mensaje << std::endl;
        return false;
    }

    ubRect = glGetUniformLocation(hudShader, "rect");
    ubColor = glGetUniformLocation(hudShader, "color");
    ubResolucion = glGetUniformLocation(hudShader, "resolucion");

    // Un cuadrado unitario (dos triangulos)
    float vertices[] =
    {
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,

        0.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f
    };

    glGenVertexArrays(1, &hudVAO);
    glGenBuffers(1, &hudVBO);

    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);

    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(vertices),
        vertices,
        GL_STATIC_DRAW
    );

    glVertexAttribPointer(
        0, 2, GL_FLOAT, GL_FALSE,
        2 * sizeof(float), (void*)0
    );

    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    return true;
}

void HudLiberar()
{
    glDeleteVertexArrays(1, &hudVAO);
    glDeleteBuffers(1, &hudVBO);
    glDeleteProgram(hudShader);
}

void HudComenzar(int ancho, int alto)
{
    hudAncho = ancho;
    hudAlto = alto;

    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glUseProgram(hudShader);
    glUniform2f(ubResolucion, (float)ancho, (float)alto);
    glBindVertexArray(hudVAO);
}

void HudTerminar()
{
    glBindVertexArray(0);
    glUseProgram(0);

    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}

void HudRect(float x, float y, float ancho, float alto, glm::vec4 color)
{
    glUniform4f(ubRect, x, y, ancho, alto);
    glUniform4f(ubColor, color.r, color.g, color.b, color.a);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

// Indice de un caracter en la tabla (si no existe, se dibuja un espacio)
static int IndiceLetra(char c)
{
    c = (char)std::toupper((unsigned char)c);

    for (int i = 0; LETRAS[i] != '\0'; i++)
    {
        if (LETRAS[i] == c)
            return i;
    }

    return 42; // espacio
}

float HudAnchoTexto(const std::string& texto, float escala)
{
    if (texto.empty())
        return 0.0f;

    // 5 pixeles por letra + 1 de separacion
    return (float)texto.size() * 6.0f * escala - escala;
}

void HudTexto(
    const std::string& texto,
    float x, float y,
    float escala,
    glm::vec4 color
)
{
    float cursorX = x;

    for (char c : texto)
    {
        const unsigned char* filas = FUENTE[IndiceLetra(c)];

        for (int fila = 0; fila < 7; fila++)
        {
            int columna = 0;

            while (columna < 5)
            {
                // Saltar pixeles apagados
                if (!(filas[fila] & (1 << (4 - columna))))
                {
                    columna++;
                    continue;
                }

                // Unir pixeles encendidos seguidos en un solo rectangulo
                int inicio = columna;

                while (columna < 5 && (filas[fila] & (1 << (4 - columna))))
                    columna++;

                HudRect(
                    cursorX + inicio * escala,
                    y + fila * escala,
                    (columna - inicio) * escala,
                    escala,
                    color
                );
            }
        }

        cursorX += 6.0f * escala;
    }
}

void HudTextoCentrado(
    const std::string& texto,
    float y,
    float escala,
    glm::vec4 color
)
{
    float ancho = HudAnchoTexto(texto, escala);

    HudTexto(texto, ((float)hudAncho - ancho) * 0.5f, y, escala, color);
}
