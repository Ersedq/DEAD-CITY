
#include "extraccion.h"
#include "escenario.h"
#include "mundo.h"

#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>

#include <cmath>
#include <algorithm>

// ---------------- AJUSTES ----------------
static const float TIEMPO_EXTRACCION = 4.0f;   // segundos que hay que aguantar dentro
static const float RETROCESO_PROGRESO = 0.5f;  // al salir, el progreso baja a esta velocidad
// -----------------------------------------

static bool activa = false;
static bool dentro = false;
static bool completada = false;
static float progreso = 0.0f;                  // 0 a 1

void ExtraccionReiniciar()
{
    activa = false;
    dentro = false;
    completada = false;
    progreso = 0.0f;
}

void ExtraccionActivar()
{
    activa = true;
}

bool ExtraccionActiva()
{
    return activa;
}

void ExtraccionActualizar(float deltaTime, glm::vec3 posicionJugador)
{
    dentro =
        std::abs(posicionJugador.x - EXTRACCION_X) < EXTRACCION_MITAD
        && std::abs(posicionJugador.z - EXTRACCION_Z) < EXTRACCION_MITAD;

    if (!activa || completada)
        return;

    if (dentro)
    {
        progreso += deltaTime / TIEMPO_EXTRACCION;

        if (progreso >= 1.0f)
        {
            progreso = 1.0f;
            completada = true;
        }
    }
    else
    {
        progreso = std::max(
            0.0f,
            progreso - deltaTime / TIEMPO_EXTRACCION * RETROCESO_PROGRESO
        );
    }
}

bool ExtraccionDentro()
{
    return dentro;
}

float ExtraccionProgreso()
{
    return progreso;
}

bool ExtraccionCompletada()
{
    return completada;
}

float ExtraccionDistancia(glm::vec3 posicionJugador)
{
    float dx = posicionJugador.x - EXTRACCION_X;
    float dz = posicionJugador.z - EXTRACCION_Z;

    return std::sqrt(dx * dx + dz * dz);
}

// ---------------------------------------------------------------------------
//  DIBUJO
// ---------------------------------------------------------------------------

static void Caja(
    const glm::mat4& vista,
    const glm::mat4& proyeccion,
    glm::vec3 posicion,
    glm::vec3 escala,
    glm::vec3 color
)
{
    MundoDibujarCuboModelo(
        vista, proyeccion,
        glm::scale(glm::translate(glm::mat4(1.0f), posicion), escala),
        color
    );
}

void ExtraccionDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
)
{
    float t = (float)glfwGetTime();
    float pulso = 0.75f + 0.25f * std::sin(t * 4.0f);

    float lado = EXTRACCION_MITAD * 2.0f;

    // Color de la zona: rojo apagado (cerrada), verde (abierta) o blanco (extrayendo)
    glm::vec3 color(2.2f, 0.25f, 0.25f);
    glm::vec3 borde(5.0f, 0.5f, 0.4f);

    if (activa)
    {
        color = glm::vec3(0.35f, 3.2f, 0.8f) * pulso;
        borde = glm::vec3(1.0f, 9.0f, 2.0f);

        // Mientras mas progreso, mas blanca se pone
        color = glm::mix(color, glm::vec3(4.0f, 4.0f, 4.0f), progreso * 0.7f);
    }

    // Piso de la zona (apenas sobre la carretera)
    Caja(vista, proyeccion,
        glm::vec3(EXTRACCION_X, -0.12f, EXTRACCION_Z),
        glm::vec3(lado, 0.05f, lado), color);

    // Borde: cuatro tiras
    float tira = 0.22f;
    float d = EXTRACCION_MITAD - tira * 0.5f;

    Caja(vista, proyeccion,
        glm::vec3(EXTRACCION_X, -0.09f, EXTRACCION_Z - d),
        glm::vec3(lado, 0.05f, tira), borde);

    Caja(vista, proyeccion,
        glm::vec3(EXTRACCION_X, -0.09f, EXTRACCION_Z + d),
        glm::vec3(lado, 0.05f, tira), borde);

    Caja(vista, proyeccion,
        glm::vec3(EXTRACCION_X - d, -0.09f, EXTRACCION_Z),
        glm::vec3(tira, 0.05f, lado), borde);

    Caja(vista, proyeccion,
        glm::vec3(EXTRACCION_X + d, -0.09f, EXTRACCION_Z),
        glm::vec3(tira, 0.05f, lado), borde);

    // Cuatro postes en las esquinas
    for (int sx = -1; sx <= 1; sx += 2)
    {
        for (int sz = -1; sz <= 1; sz += 2)
        {
            Caja(vista, proyeccion,
                glm::vec3(
                    EXTRACCION_X + sx * EXTRACCION_MITAD,
                    1.25f,
                    EXTRACCION_Z + sz * EXTRACCION_MITAD),
                glm::vec3(0.25f, 2.7f, 0.25f), borde);
        }
    }

    // Columna de luz en el centro (solo cuando esta abierta): se ve desde toda la calle
    if (activa)
    {
        Caja(vista, proyeccion,
            glm::vec3(EXTRACCION_X, 7.0f, EXTRACCION_Z),
            glm::vec3(0.6f * pulso, 14.0f, 0.6f * pulso),
            glm::vec3(1.5f, 14.0f, 3.0f));
    }
}
