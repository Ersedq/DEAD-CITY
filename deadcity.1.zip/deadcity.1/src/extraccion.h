#ifndef EXTRACCION_H
#define EXTRACCION_H

#include <glm/glm.hpp>

// Zona de extraccion: al terminar las oleadas se abre y hay que llegar
// hasta ella y aguantar unos segundos dentro para escapar (y ganar).
// Antes de abrirse se ve en rojo para que sepas hacia donde ir.

// Vuelve a dejarla cerrada
void ExtraccionReiniciar();

// Abre la zona (se llama al terminar la ultima oleada)
void ExtraccionActivar();

bool ExtraccionActiva();

// Cuenta el tiempo dentro de la zona
void ExtraccionActualizar(float deltaTime, glm::vec3 posicionJugador);

void ExtraccionDibujar(
    const glm::mat4& vista,
    const glm::mat4& proyeccion
);

// El jugador esta dentro del cuadrado
bool ExtraccionDentro();

// 0 a 1: cuanto falta para que llegue el helicoptero
float ExtraccionProgreso();

// true cuando se completa el tiempo dentro de la zona
bool ExtraccionCompletada();

// Metros desde el jugador hasta el centro de la zona
float ExtraccionDistancia(glm::vec3 posicionJugador);

#endif
