@echo off
REM Compila DEAD CITY (hace falta MSYS2 MinGW64 con g++, glfw, glew y glm; ver README.md)
g++ -std=c++20 -O2 -static-libgcc -static-libstdc++ src/*.cpp -o DEAD_CITY.exe -lglew32 -lglfw3 -lopengl32 -lgdi32
if errorlevel 1 (
    echo.
    echo ERROR al compilar.
    exit /b 1
)
echo.
echo Listo: DEAD_CITY.exe
echo Para compartirlo, junto al .exe debe ir glew32.dll (esta en C:\msys64\mingw64\bin).
