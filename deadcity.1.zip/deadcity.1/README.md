# DEAD CITY
Esto es un juego de supervivencia contra zombis en primera persona, hecho en C++ con OpenGL 3.3.
Sobrevives a 3 oleadas de zombis en una calle de noche y luego debes llegar a la "zona de extracción" para escapar.

## Descripción del juego

- Despiertas al inicio de una calle oscura rodeada de edificios abandonados.
- Debes sobrevivir a 3 oleadas de zombis; cada oleada trae mas zombis, mas rápidos y que golpean mas fuerte.
- Hay 3 tipos de zombis:
  - Normal: 100 de vida.
  - Corredor (desde la oleada 2): rápido y frágil.
  - Tanque (desde la oleada 3): lento, enorme y muy resistente.
- Tienes 3 armas: pistola, rifle (automático) y escopeta (8 perdigones). Un disparo a la cabeza hace doble daño.
- Al superar una oleada recuperas algo de vida y munición.
- De vez en cuando aparecen **coleccionables** (botiquín de vida y caja de municion), y los zombis a veces los sueltan al morir.
- Al vencer la ultima oleada se abre la **zona de extracción** (columna de luz verde al fondo de la calle). Debes llegar y aguantar 4 segundos dentro mientras siguen llegando refuerzos.
- Puntaje: puntos por cada zombi (mas por los fuertes), bono por tiro a la cabeza, bono por tiempo y bono por la vida con la que te extraes.
- Pierdes si tu vida llega a 0.

## Controles

| Tecla / accion | Funcion |
|----------------|---------|
| W A S D | Moverse |
| Raton | Mirar |
| Shift | Correr |
| Espacio | Saltar |
| Clic izquierdo | Disparar |
| R | Recargar (en la pantalla final: reiniciar) |
| 1 / 2 / 3 | Pistola / Rifle / Escopeta |
| ESC | Soltar el raton (clic para volver al juego) |

# Instalacion y ejecucion

# Opción A: jugar el juego ya compilado (Windows)

1. Descarga el zip desde la seccion **Releases** de este repositorio.
2. Descomprime el zip (deben quedar juntos `DEAD_CITY.exe` y `glew32.dll`).
3. Haz doble clic en `DEAD_CITY.exe`.

# Opción B: compilar desde el código (Windows)

1. Instala [MSYS2](https://www.msys2.org/).
2. Abre la terminal **MSYS2 MINGW64** e instala las librerías:
   ```
   pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-glfw mingw-w64-x86_64-glew mingw-w64-x86_64-glm
   ```
3. Agrega `C:\msys64\mingw64\bin` a la variable de entorno PATH.
4. En la carpeta del proyecto ejecuta:
   ```
   g++ -std=c++20 -O2 -static-libgcc -static-libstdc++ src/*.cpp -o DEAD_CITY.exe -lglew32 -lglfw3 -lopengl32 -lgdi32
   ```
   (o simplemente `build.bat`).
5. Copia `glew32.dll` (de `C:\msys64\mingw64\bin`) junto al `.exe` y ejecuta `.\DEAD_CITY.exe`.

*Requisitos:* Windows 10 u 11 y una tarjeta grafica con soporte de OpenGL 3.3.

## Estructura del proyecto

| Archivo | Que hace |
|---------|----------|
| `src/main.cpp` | Ventana, bucle principal, estados de la partida, HUD, tiempo y puntaje |
| `src/Mundo.cpp` | Escenario nocturno, shader de luces y niebla, dibujo de cubos |
| `src/escenario.h` | Datos del escenario (edificios, farolas, zona de extraccion) compartidos por dibujo y colisiones |
| `src/Jugador.cpp` | Camara en primera persona, movimiento, salto, vida y colisiones |
| `src/Zombis.cpp` | Zombis, tipos, oleadas, IA de persecucion y disparos |
| `src/Arma.cpp` | Armas, municion, recarga y arma en primera persona |
| `src/Objetos.cpp` | Coleccionables (vida y municion) |
| `src/Extraccion.cpp` | Zona de extraccion y condicion de victoria |
| `src/Hud.cpp` | Dibujo 2D: rectangulos y fuente de pixeles propia |

## Fuentes de recursos externos

El juego **no usa modelos 3D, texturas, imagenes ni audio externos**: todo se dibuja con cubos generados por codigo
y la fuente del HUD es una fuente de pixeles de 5x7 definida en `Hud.cpp`.

Solo se usan estas librerias:

| Libreria | Uso | Sitio | Licencia |
|----------|-----|-------|----------|
| GLFW | Ventana, teclado y raton | https://www.glfw.org/ | zlib/libpng |
| GLEW | Cargar funciones de OpenGL | https://glew.sourceforge.net/ | Modified BSD / MIT |
| GLM | Matematicas (vectores y matrices) | https://github.com/g-truc/glm | MIT |
| MSYS2 / MinGW-w64 | Compilador g++ y gestor de paquetes | https://www.msys2.org/ | Varias (GCC: GPL con excepcion de runtime) |
